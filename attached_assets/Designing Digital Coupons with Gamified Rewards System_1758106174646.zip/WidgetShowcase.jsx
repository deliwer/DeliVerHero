import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Code, Monitor, Smartphone, Palette } from 'lucide-react'

function WidgetShowcase() {
  const [widgetLoaded, setWidgetLoaded] = useState(false)

  useEffect(() => {
    // Load the widget script
    const script = document.createElement('script')
    script.src = '/widget.js'
    script.onload = () => setWidgetLoaded(true)
    document.head.appendChild(script)

    return () => {
      // Cleanup
      if (document.head.contains(script)) {
        document.head.removeChild(script)
      }
    }
  }, [])

  const embedCode = `<!-- Planet Heroes Widget -->
<div id="planet-heroes-widget"></div>
<script>
  window.PlanetHeroesConfig = {
    userPoints: 18500,
    userLevel: "Planet Hero",
    theme: "light",
    size: "full"
  };
</script>
<script src="https://cdn.deliwer.com/widget.js"></script>`

  const compactEmbedCode = `<!-- Planet Heroes Compact Widget -->
<div id="planet-heroes-widget"></div>
<script>
  window.PlanetHeroesConfig = {
    userPoints: 18500,
    userLevel: "Planet Hero",
    theme: "light",
    size: "compact"
  };
</script>
<script src="https://cdn.deliwer.com/widget.js"></script>`

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Planet Heroes Widget Integration</h2>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Easily integrate the Planet Heroes experience into your website with our embeddable widget.
        </p>
      </div>

      <Tabs defaultValue="demo" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="demo">Live Demo</TabsTrigger>
          <TabsTrigger value="integration">Integration</TabsTrigger>
          <TabsTrigger value="customization">Customization</TabsTrigger>
        </TabsList>

        <TabsContent value="demo" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Full Widget Demo */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <Monitor className="h-5 w-5" />
                      <span>Full Widget</span>
                    </CardTitle>
                    <CardDescription>800px × 600px - Perfect for main content areas</CardDescription>
                  </div>
                  <Badge variant="secondary">Recommended</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-4 bg-gray-50">
                  <div className="w-full h-96 bg-white rounded border flex items-center justify-center">
                    {widgetLoaded ? (
                      <iframe 
                        src="/widget-demo.html?size=full&theme=light" 
                        className="w-full h-full border-0 rounded"
                        title="Planet Heroes Full Widget Demo"
                      />
                    ) : (
                      <div className="text-center text-gray-500">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto mb-2"></div>
                        Loading widget...
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Compact Widget Demo */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <Smartphone className="h-5 w-5" />
                      <span>Compact Widget</span>
                    </CardTitle>
                    <CardDescription>320px × 400px - Great for sidebars and mobile</CardDescription>
                  </div>
                  <Badge variant="outline">Mobile Friendly</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-4 bg-gray-50">
                  <div className="w-80 h-96 bg-white rounded border mx-auto flex items-center justify-center">
                    {widgetLoaded ? (
                      <iframe 
                        src="/widget-demo.html?size=compact&theme=light" 
                        className="w-full h-full border-0 rounded"
                        title="Planet Heroes Compact Widget Demo"
                      />
                    ) : (
                      <div className="text-center text-gray-500">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto mb-2"></div>
                        Loading widget...
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="integration" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Code className="h-5 w-5" />
                  <span>Full Widget Integration</span>
                </CardTitle>
                <CardDescription>Copy and paste this code into your website</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                  <pre className="text-sm">
                    <code>{embedCode}</code>
                  </pre>
                </div>
                <Button 
                  className="mt-4 w-full" 
                  onClick={() => navigator.clipboard.writeText(embedCode)}
                >
                  Copy Code
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Code className="h-5 w-5" />
                  <span>Compact Widget Integration</span>
                </CardTitle>
                <CardDescription>Smaller version for sidebars and mobile layouts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                  <pre className="text-sm">
                    <code>{compactEmbedCode}</code>
                  </pre>
                </div>
                <Button 
                  className="mt-4 w-full" 
                  onClick={() => navigator.clipboard.writeText(compactEmbedCode)}
                >
                  Copy Code
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Integration Steps</CardTitle>
              <CardDescription>Follow these simple steps to add Planet Heroes to your website</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="bg-emerald-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">1</div>
                  <div>
                    <h3 className="font-semibold">Choose Widget Size</h3>
                    <p className="text-gray-600">Select between full (800×600px) or compact (320×400px) widget</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-emerald-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">2</div>
                  <div>
                    <h3 className="font-semibold">Copy Integration Code</h3>
                    <p className="text-gray-600">Copy the HTML/JavaScript code from the integration tab</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-emerald-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">3</div>
                  <div>
                    <h3 className="font-semibold">Paste Into Your Website</h3>
                    <p className="text-gray-600">Add the code to your HTML where you want the widget to appear</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-emerald-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">4</div>
                  <div>
                    <h3 className="font-semibold">Configure User Data</h3>
                    <p className="text-gray-600">Update userPoints and userLevel in the configuration object</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customization" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Palette className="h-5 w-5" />
                  <span>Theme Options</span>
                </CardTitle>
                <CardDescription>Customize the widget appearance to match your brand</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg bg-white">
                      <h4 className="font-semibold mb-2">Light Theme</h4>
                      <div className="text-sm text-gray-600">
                        <code>theme: "light"</code>
                      </div>
                      <div className="mt-2 h-16 bg-gradient-to-r from-white to-gray-100 rounded border"></div>
                    </div>
                    
                    <div className="p-4 border rounded-lg bg-gray-900 text-white">
                      <h4 className="font-semibold mb-2">Dark Theme</h4>
                      <div className="text-sm text-gray-300">
                        <code>theme: "dark"</code>
                      </div>
                      <div className="mt-2 h-16 bg-gradient-to-r from-gray-800 to-gray-900 rounded border border-gray-700"></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configuration Options</CardTitle>
                <CardDescription>Available parameters for widget customization</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-mono text-sm">userPoints</span>
                    <span className="text-gray-600">User's current point balance</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-mono text-sm">userLevel</span>
                    <span className="text-gray-600">Current achievement level</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-mono text-sm">theme</span>
                    <span className="text-gray-600">"light" or "dark"</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-mono text-sm">size</span>
                    <span className="text-gray-600">"full" or "compact"</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2">
                    <span className="font-mono text-sm">language</span>
                    <span className="text-gray-600">"en" or "ar" (optional)</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Advanced Configuration Example</CardTitle>
              <CardDescription>Full configuration with all available options</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                <pre className="text-sm">
                  <code>{`window.PlanetHeroesConfig = {
  userPoints: 18500,
  userLevel: "Planet Hero",
  theme: "light",
  size: "full",
  language: "en",
  showImpact: true,
  showAchievements: true,
  showCommunity: true,
  customColors: {
    primary: "#059669",
    secondary: "#10b981"
  }
};`}</code>
                </pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default WidgetShowcase

