import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Gift, Leaf, Droplets, Coffee, Star, Trophy, Users, Recycle, Settings } from 'lucide-react'
import { motion } from 'framer-motion'
import WidgetDemo from './components/WidgetDemo'
import './App.css'

// Import images
import planetHeroesCoupon from './assets/planet_heroes_coupon_main.png'
import bakersKitchenCoupon from './assets/bakers_kitchen_smoothie_coupon.png'
import aquacafeCoupon from './assets/aquacafe_system_coupon.png'
import deliwerLogo from './assets/deliwerlogo.png'

function App() {
  const [currentView, setCurrentView] = useState('vouchers') // 'vouchers' or 'widget-demo'
  const [planetPoints, setPlanetPoints] = useState(18500)
  const [selectedCoupon, setSelectedCoupon] = useState(null)
  const [userLevel, setUserLevel] = useState('Planet Hero')
  const [impactStats, setImpactStats] = useState({
    bottlesPrevented: 47,
    co2Saved: 12.3,
    treesPlanted: 3
  })

  if (currentView === 'widget-demo') {
    return <WidgetDemo />
  }

  const coupons = [
    {
      id: 1,
      title: 'Planet Heroes Package',
      description: 'Complete eco-friendly package at Mazaya Center',
      points: 18500,
      value: 'AED 1,850',
      image: planetHeroesCoupon,
      category: 'Premium',
      available: true,
      includes: ['AquaCafe Pro System', 'Bakers Kitchen Vouchers', 'Environmental Impact Tracking']
    },
    {
      id: 2,
      title: 'AquaCafe Pro System',
      description: '5-stage water purification system',
      points: 15000,
      value: 'AED 1,500',
      image: aquacafeCoupon,
      category: 'Water',
      available: true,
      includes: ['Free Installation', 'Premium Water Access', '1 Year Warranty']
    },
    {
      id: 3,
      title: 'Bakers Kitchen Smoothies',
      description: 'Buy one smoothie, get one free',
      points: 3500,
      value: 'AED 350',
      image: bakersKitchenCoupon,
      category: 'Food',
      available: true,
      includes: ['Any Smoothie Flavor', 'Same Day Use', 'Mazaya Center Location']
    }
  ]

  const achievements = [
    { icon: Trophy, title: 'Planet Hero', description: 'Joined the environmental movement', unlocked: true },
    { icon: Droplets, title: 'Water Saver', description: 'Prevented 50+ plastic bottles', unlocked: impactStats.bottlesPrevented >= 50 },
    { icon: Recycle, title: 'Eco Warrior', description: 'Traded 5+ devices', unlocked: false },
    { icon: Star, title: 'Community Leader', description: 'Referred 10+ friends', unlocked: false }
  ]

  const redeemCoupon = (coupon) => {
    if (planetPoints >= coupon.points) {
      setPlanetPoints(prev => prev - coupon.points)
      setSelectedCoupon(coupon)
      // Update impact stats
      setImpactStats(prev => ({
        bottlesPrevented: prev.bottlesPrevented + Math.floor(coupon.points / 100),
        co2Saved: prev.co2Saved + (coupon.points / 1000),
        treesPlanted: prev.treesPlanted + Math.floor(coupon.points / 5000)
      }))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img src={deliwerLogo} alt="DeliWer" className="h-8 w-auto" />
              <h1 className="text-2xl font-bold text-gray-900">Planet Heroes Voucher System</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                onClick={() => setCurrentView(currentView === 'vouchers' ? 'widget-demo' : 'vouchers')}
              >
                <Settings className="w-4 h-4 mr-2" />
                {currentView === 'vouchers' ? 'Widget Demo' : 'Back to App'}
              </Button>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <Leaf className="w-4 h-4 mr-2" />
                {planetPoints.toLocaleString()} PTS
              </Badge>
              <Badge variant="outline">{userLevel}</Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="vouchers" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="vouchers">Vouchers</TabsTrigger>
            <TabsTrigger value="impact">My Impact</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="community">Community</TabsTrigger>
          </TabsList>

          {/* Vouchers Tab */}
          <TabsContent value="vouchers" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Redeem Your Planet Points</h2>
              <p className="text-lg text-gray-600">Transform your environmental impact into amazing rewards</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {coupons.map((coupon) => (
                <motion.div
                  key={coupon.id}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <img 
                        src={coupon.image} 
                        alt={coupon.title}
                        className="w-full h-48 object-cover"
                      />
                      <Badge className="absolute top-2 right-2" variant="secondary">
                        {coupon.category}
                      </Badge>
                    </div>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        {coupon.title}
                        <span className="text-green-600 font-bold">{coupon.points.toLocaleString()} PTS</span>
                      </CardTitle>
                      <CardDescription>{coupon.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="text-sm text-gray-600">
                          <p className="font-semibold">Includes:</p>
                          <ul className="list-disc list-inside space-y-1">
                            {coupon.includes.map((item, index) => (
                              <li key={index}>{item}</li>
                            ))}
                          </ul>
                        </div>
                        <Button 
                          className="w-full" 
                          onClick={() => redeemCoupon(coupon)}
                          disabled={planetPoints < coupon.points}
                        >
                          <Gift className="w-4 h-4 mr-2" />
                          Redeem for {coupon.value}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Impact Tab */}
          <TabsContent value="impact" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Your Environmental Impact</h2>
              <p className="text-lg text-gray-600">See how you're helping save the planet</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="text-center">
                  <Droplets className="w-12 h-12 mx-auto text-blue-500 mb-2" />
                  <CardTitle>{impactStats.bottlesPrevented}</CardTitle>
                  <CardDescription>Plastic Bottles Prevented</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Leaf className="w-12 h-12 mx-auto text-green-500 mb-2" />
                  <CardTitle>{impactStats.co2Saved} kg</CardTitle>
                  <CardDescription>CO₂ Saved</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Recycle className="w-12 h-12 mx-auto text-emerald-500 mb-2" />
                  <CardTitle>{impactStats.treesPlanted}</CardTitle>
                  <CardDescription>Trees Planted Equivalent</CardDescription>
                </CardHeader>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Progress to Next Level</CardTitle>
                <CardDescription>Earn more points to unlock exclusive rewards</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress value={75} className="w-full" />
                  <p className="text-sm text-gray-600">2,500 more points to reach "Eco Champion" level</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Your Achievements</h2>
              <p className="text-lg text-gray-600">Unlock badges as you make a difference</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {achievements.map((achievement, index) => (
                <Card key={index} className={achievement.unlocked ? 'border-green-200 bg-green-50' : 'opacity-60'}>
                  <CardHeader>
                    <div className="flex items-center space-x-4">
                      <achievement.icon className={`w-8 h-8 ${achievement.unlocked ? 'text-green-600' : 'text-gray-400'}`} />
                      <div>
                        <CardTitle className="flex items-center space-x-2">
                          {achievement.title}
                          {achievement.unlocked && <Badge variant="secondary">Unlocked</Badge>}
                        </CardTitle>
                        <CardDescription>{achievement.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Community Tab */}
          <TabsContent value="community" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Planet Heroes Community</h2>
              <p className="text-lg text-gray-600">Join Dubai's largest environmental community</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="text-center">
                  <Users className="w-12 h-12 mx-auto text-blue-500 mb-2" />
                  <CardTitle>12,847</CardTitle>
                  <CardDescription>Planet Heroes</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Droplets className="w-12 h-12 mx-auto text-blue-500 mb-2" />
                  <CardTitle>2.4M</CardTitle>
                  <CardDescription>Bottles Prevented</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Leaf className="w-12 h-12 mx-auto text-green-500 mb-2" />
                  <CardTitle>180T</CardTitle>
                  <CardDescription>CO₂ Saved</CardDescription>
                </CardHeader>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Current Community Challenge</CardTitle>
                <CardDescription>1 Million Bottles by Ramadan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress value={80} className="w-full" />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>800,000 bottles prevented</span>
                    <span>23 days left</span>
                  </div>
                  <Button className="w-full">
                    Join Challenge
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Redemption Modal */}
      {selectedCoupon && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedCoupon(null)}
        >
          <motion.div 
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="bg-white rounded-lg p-6 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Voucher Redeemed!</h3>
              <p className="text-gray-600 mb-4">
                Your {selectedCoupon.title} voucher has been added to your wallet.
              </p>
              <Button onClick={() => setSelectedCoupon(null)} className="w-full">
                View in Wallet
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  )
}

export default App

