import WidgetShowcase from './WidgetShowcase'

function WidgetPage() {
  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <WidgetShowcase />
      </div>
    </div>
  )
}

export default WidgetPage

