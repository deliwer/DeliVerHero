import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Code, Monitor, Smartphone, Palette } from 'lucide-react'
import EmbeddableWidget from './EmbeddableWidget'

const WidgetDemo = () => {
  const [widgetConfig, setWidgetConfig] = useState({
    compact: false,
    theme: 'light',
    userPoints: 18500,
    userLevel: 'Planet Hero'
  })

  const generateEmbedCode = (config) => {
    return `<!-- Planet Heroes Widget -->
<div id="planet-heroes-widget"></div>
<script>
  window.PlanetHeroesConfig = {
    userPoints: ${config.userPoints},
    userLevel: "${config.userLevel}",
    compact: ${config.compact},
    theme: "${config.theme}",
    containerId: "planet-heroes-widget"
  };
</script>
<script src="https://cdn.deliwer.com/widgets/planet-heroes.js"></script>`
  }

  const generateReactCode = (config) => {
    return `import EmbeddableWidget from './components/EmbeddableWidget'

function App() {
  return (
    <EmbeddableWidget
      userPoints={${config.userPoints}}
      userLevel="${config.userLevel}"
      compact={${config.compact}}
      theme="${config.theme}"
    />
  )
}`
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Planet Heroes Widget Demo
          </h1>
          <p className="text-lg text-gray-600">
            Embeddable voucher system for the DeliWer Shopping website
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Configuration Panel */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Palette className="w-5 h-5 mr-2" />
                  Widget Configuration
                </CardTitle>
                <CardDescription>
                  Customize the widget appearance and behavior
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="compact-mode">Compact Mode</Label>
                    <Switch
                      id="compact-mode"
                      checked={widgetConfig.compact}
                      onCheckedChange={(checked) =>
                        setWidgetConfig(prev => ({ ...prev, compact: checked }))
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Theme</Label>
                    <div className="flex space-x-2">
                      <Button
                        variant={widgetConfig.theme === 'light' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setWidgetConfig(prev => ({ ...prev, theme: 'light' }))}
                      >
                        Light
                      </Button>
                      <Button
                        variant={widgetConfig.theme === 'dark' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setWidgetConfig(prev => ({ ...prev, theme: 'dark' }))}
                      >
                        Dark
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>User Points</Label>
                    <div className="flex space-x-2">
                      {[5000, 15000, 25000].map(points => (
                        <Button
                          key={points}
                          variant={widgetConfig.userPoints === points ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setWidgetConfig(prev => ({ ...prev, userPoints: points }))}
                        >
                          {points.toLocaleString()}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>User Level</Label>
                    <div className="flex flex-col space-y-2">
                      {['New Hero', 'Planet Hero', 'Eco Champion'].map(level => (
                        <Button
                          key={level}
                          variant={widgetConfig.userLevel === level ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setWidgetConfig(prev => ({ ...prev, userLevel: level }))}
                        >
                          {level}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-2">Widget Sizes</h4>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex justify-between">
                      <span>Compact:</span>
                      <span>320px × 400px</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Full:</span>
                      <span>800px × 600px</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Widget Preview */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Monitor className="w-5 h-5 mr-2" />
                  Live Preview
                </CardTitle>
                <CardDescription>
                  See how the widget will appear on your website
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-white p-6 rounded-lg border-2 border-dashed border-gray-200">
                  <EmbeddableWidget {...widgetConfig} />
                </div>
              </CardContent>
            </Card>

            {/* Integration Code */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Code className="w-5 h-5 mr-2" />
                  Integration Code
                </CardTitle>
                <CardDescription>
                  Copy and paste this code into your website
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="html">
                  <TabsList>
                    <TabsTrigger value="html">HTML/JavaScript</TabsTrigger>
                    <TabsTrigger value="react">React Component</TabsTrigger>
                  </TabsList>
                  <TabsContent value="html">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{generateEmbedCode(widgetConfig)}</code>
                      </pre>
                      <Button
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => navigator.clipboard.writeText(generateEmbedCode(widgetConfig))}
                      >
                        Copy
                      </Button>
                    </div>
                  </TabsContent>
                  <TabsContent value="react">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{generateReactCode(widgetConfig)}</code>
                      </pre>
                      <Button
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => navigator.clipboard.writeText(generateReactCode(widgetConfig))}
                      >
                        Copy
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Features Overview */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Widget Features</CardTitle>
            <CardDescription>
              Complete gamified rewards system for environmental impact
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Monitor className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2">Responsive Design</h3>
                <p className="text-sm text-gray-600">
                  Works perfectly on desktop and mobile devices
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Smartphone className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold mb-2">Easy Integration</h3>
                <p className="text-sm text-gray-600">
                  Simple embed code or React component
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Palette className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">Customizable</h3>
                <p className="text-sm text-gray-600">
                  Multiple themes and configuration options
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Code className="w-6 h-6 text-orange-600" />
                </div>
                <h3 className="font-semibold mb-2">Real-time Updates</h3>
                <p className="text-sm text-gray-600">
                  Live points balance and community stats
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default WidgetDemo

