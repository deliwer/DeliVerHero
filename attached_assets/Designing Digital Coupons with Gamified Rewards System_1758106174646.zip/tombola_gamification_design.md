# Tombola Gamification Design for AquaCafe Hero Rewards System

## 1. Introduction

This document outlines the design for integrating a tombola game into the existing AquaCafe Hero rewards points digital voucher system on www.deliwer.com/aquacafe. The primary goal is to enhance user engagement, incentivize sustainable practices, and drive participation in the referral program through a seamless play-earn-rewards process flow. This gamified approach will further strengthen the circular exchange and sustainability missions central to the Planet Heroes community.

## 2. Play -> Earn -> Rewards Process Flow

The tombola game will operate on a clear and intuitive cycle:

### 2.1. Play Mechanics

Users will "play" the tombola by spending earned tombola tickets. Each ticket grants one spin of the digital tombola wheel, offering a chance to win various prizes. The act of playing is designed to be visually engaging and exciting, reinforcing the gamified experience.

### 2.2. Earn Mechanics (Ticket Earning)

Tombola tickets are the currency for playing the game. Users will earn these tickets through specific actions that align with the AquaCafe Hero program's objectives:

*   **AquaCafe Starter Kit Purchase:** Upon activation of the AED 99 AquaCafe Starter Kit, users will receive 5 tombola tickets. This incentivizes initial program adoption and loyalty membership.
*   **Sustainable Water Consumption:**
    *   Tier 1 (50L saved): 1 ticket
    *   Tier 2 (100L saved): 2 tickets
    *   Tier 3 (250L saved): 3 tickets
    These tiers will be tracked through the AquaCafe system, directly linking tickets to measurable environmental impact.
*   **Community Engagement:**
    *   Monthly Challenge Completion: 1 ticket per challenge.
    *   Active Forum Participation: 1 ticket weekly for meaningful contributions.
    *   Sharing Sustainability Tips: 1 ticket per approved tip (e.g., via a submission form or social media sharing with a specific hashtag).
    These activities foster a sense of community and collective effort towards sustainability.
*   **Sven the Bakers Kitchen Activities:**
    *   Dine-in/Takeaway (minimum AED 50 spend): 1 ticket per transaction. This drives footfall and engagement with a key partner.
    *   Voucher Redemption: 1 bonus ticket for redeeming any AquaCafe or Planet Heroes voucher at Sven the Bakers Kitchen, encouraging voucher utilization.
*   **Referral Program Integration:**
    *   **Referrer Rewards:** When a user refers a friend who purchases the AED 99 AquaCafe Starter Kit, the referrer receives 3 tombola tickets (in addition to the Sven the Bakers Kitchen voucher).
    *   **New User Rewards:** The newly referred user also receives 3 bonus tombola tickets upon their Starter Kit purchase, providing an immediate incentive to engage with the gamified system.

### 2.3. Rewards Mechanics (Prize Distribution and Redemption)

The tombola will feature a tiered prize system to maintain excitement and offer a range of incentives:

*   **Tier 1: Common Prizes (Frequent Wins)**
    *   DeliWer discount codes (e.g., 10% off next order)
    *   Free delivery vouchers for DeliWer
    *   Small Sven the Bakers Kitchen treats (e.g., free coffee, cookie)
    *   Digital badges or in-game currency (e.g., bonus Planet Points)
*   **Tier 2: Mid-Tier Prizes**
    *   AED 50 Sven the Bakers Kitchen voucher
    *   AquaCafe merchandise (e.g., water bottle, tote bag)
    *   DeliWer credit (e.g., AED 25)
    *   Exclusive access to new AquaCafe features or early bird offers
*   **Tier 3: Grand Prizes (Special Draws)**
    *   Dinner for two at Sven the Bakers Kitchen (up to AED 200 value)
    *   Year's supply of AquaCafe water filters
    *   High-value DeliWer credit (e.g., AED 100)
    *   Exclusive 'Planet Hero' merchandise bundle

**Prize Fulfillment:**
*   **Digital Prizes:** Automatically applied to user accounts within the DeliWer platform (e.g., discount codes, Planet Points, digital badges).
*   **Physical Prizes:** Available for collection at Sven the Bakers Kitchen or delivered through DeliWer, depending on the prize type and user preference.

## 3. Integration with Circular Exchange and Sustainability Missions

The tombola game is designed to be more than just a random draw; it's a tool to reinforce the core values of the Planet Heroes program:

*   **Incentivizing Sustainable Actions:** The primary earning mechanics for tickets are directly tied to sustainable behaviors (water saving, community engagement, eco-friendly purchases).
*   **Promoting Circular Economy:** By integrating with the AED 99 Starter Kit and referral program, the tombola encourages participation in the AquaCafe Loyalty Gateway, which is positioned as a "circular exchange hub" with trade-in options and Planet Points redemption.
*   **Community Building:** Earning tickets through community challenges and sharing tips strengthens the collective mission and encourages peer-to-peer learning and support.
*   **Brand Alignment:** The prizes, particularly those from Sven the Bakers Kitchen and AquaCafe merchandise, reinforce the partnership and the healthy, sustainable lifestyle promoted by both brands.

## 4. Mapping Tombola Tickets to Planet Points

While tombola tickets are a separate currency for playing the game, they will be intrinsically linked to the Planet Points system. For instance, some tombola prizes will directly award Planet Points, and the overall engagement with the tombola system will contribute to a user's Planet Hero level progression. This ensures that all gamified elements contribute to the overarching loyalty program.

## 5. Technical Considerations (High-Level)

*   **Digital Ticket System:** Tickets will be automatically credited to a user's AquaCafe Planet Heroes profile within the DeliWer platform. In-app and email notifications will confirm ticket earnings.
*   **Draw Frequency:** Weekly draws will provide regular engagement, with special monthly/quarterly draws for grand prizes to build anticipation.
*   **Ticket Expiry:** Initially, tickets will have no expiry to encourage accumulation and reduce user frustration, promoting long-term engagement.

This design aims to create an exciting, rewarding, and purpose-driven gamified experience that deeply integrates with the AquaCafe Hero rewards system and the broader Planet Heroes mission.

