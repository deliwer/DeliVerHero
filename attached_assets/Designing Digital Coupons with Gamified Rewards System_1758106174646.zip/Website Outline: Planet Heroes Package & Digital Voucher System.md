# Website Outline: Planet Heroes Package & Digital Voucher System

## 1. Home Page (index.html)
- **Hero Section:**
  - Title: Planet Heroes: Empowering Eco-Conscious Consumers
  - Subtitle: Turn your environmental actions into exclusive rewards with DeliWer.
  - Call to Action: Join Now / Explore Vouchers
  - Background Image: Mazaya Center (similar to presentation title slide)
- **What is Planet Heroes?**
  - Mission, Community, Rewards (brief overview)
  - Key Impact Metrics (Bottles Prevented, CO₂ Saved, Planet Heroes)
- **Featured Vouchers:**
  - Planet Heroes Package (brief description, points, value)
  - AquaCafe Pro System (brief description, points, value)
  - Bakers Kitchen Smoothies (brief description, points, value)
- **How it Works (Simplified):**
  - Earn Points (device trading, eco-activities)
  - Track Impact (personal dashboard)
  - Redeem Rewards (vouchers, products)
- **Call to Action:** Learn More / Get Started

## 2. Vouchers Page (vouchers.html)
- **Header:** Browse Our Eco-Friendly Rewards
- **Voucher Listings:**
  - Planet Heroes Package (detailed description, points, value, image)
  - AquaCafe Pro System (detailed description, points, value, image)
  - Bakers Kitchen Smoothies (detailed description, points, value, image)
  - Referral Starter Kit (detailed description, AED 99, pizza + smoothie vouchers, images)
- **Call to Action:** Redeem Now (links to the digital voucher system)

## 3. My Impact Page (my-impact.html)
- **Header:** Your Environmental Impact
- **Impact Metrics:**
  - Plastic Bottles Prevented
  - CO₂ Saved
  - Trees Planted Equivalent
- **Progress to Next Level:**
  - Current level, points needed for next level
- **Achievements:**
  - List of badges (e.g., Planet Hero, Water Saver, Eco Warrior, Community Leader)

## 4. About Us / Mission Page (about.html)
- **Header:** Our Mission: A Greener Planet Together
- **Detailed Mission Statement:**
  - Explanation of DeliWer's commitment to sustainability
  - Importance of community involvement
- **How Planet Heroes Works (Detailed):**
  - In-depth explanation of earning points, impact tracking, and redemption process.
- **Partnerships:**
  - Mazaya Center, Bakers Kitchen, AquaCafe

## 5. Contact Page (contact.html)
- **Header:** Get in Touch
- **Contact Form:** (Placeholder for future implementation)
- **Contact Information:**
  - Email: formatix@deliwer.com
  - Phone: +971523946311
  - Website: www.deliwer.com
  - Location: Mazaya Center, Dubai

## 6. Footer (common to all pages)
- DeliWer Logo
- Quick Links (Home, Vouchers, My Impact, About, Contact)
- Social Media Links (Placeholder)
- Copyright Information

## General Website Style Guidelines:
- **Color Palette:** Consistent with presentation (#059669, #10b981, #d1fae5, #1f2937, #f3f4f6)
- **Typography:** Poppins for headings, Open Sans for body text
- **Layout:** Clean, modern, responsive design. Use Tailwind CSS.
- **Images:** High-quality, relevant images for each section.
- **Interactive Elements:** Buttons, links, clear calls to action.
- **Embeddable Widget:** Will be integrated on the Vouchers or My Impact page for demonstration.

