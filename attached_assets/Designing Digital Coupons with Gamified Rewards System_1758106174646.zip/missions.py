from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
import random

missions_bp = Blueprint('missions', __name__)

# Mock sustainability missions data
SUSTAINABILITY_MISSIONS = [
    {
        'id': 1,
        'title': 'Plastic-Free Week Challenge',
        'description': 'Avoid single-use plastic for 7 consecutive days',
        'points_reward': 500,
        'tickets_reward': 2,
        'duration_days': 7,
        'category': 'plastic_reduction',
        'difficulty': 'medium',
        'icon': '🌱'
    },
    {
        'id': 2,
        'title': 'Refill Station Hero',
        'description': 'Use AquaCafe refill stations 5 times this week',
        'points_reward': 300,
        'tickets_reward': 1,
        'duration_days': 7,
        'category': 'water_refill',
        'difficulty': 'easy',
        'icon': '💧'
    },
    {
        'id': 3,
        'title': 'Community Ambassador',
        'description': 'Refer 3 friends to join Planet Heroes',
        'points_reward': 1000,
        'tickets_reward': 5,
        'duration_days': 30,
        'category': 'community',
        'difficulty': 'hard',
        'icon': '👥'
    },
    {
        'id': 4,
        'title': 'Zero Waste Lunch',
        'description': 'Bring reusable containers for 5 meals',
        'points_reward': 250,
        'tickets_reward': 1,
        'duration_days': 14,
        'category': 'waste_reduction',
        'difficulty': 'easy',
        'icon': '🍱'
    },
    {
        'id': 5,
        'title': 'Eco Transport Champion',
        'description': 'Use sustainable transport (walk/bike/public) for 10 trips',
        'points_reward': 400,
        'tickets_reward': 2,
        'duration_days': 14,
        'category': 'transport',
        'difficulty': 'medium',
        'icon': '🚲'
    }
]

# Mock user missions progress
USER_MISSIONS = {
    1: [  # User ID 1
        {
            'mission_id': 1,
            'status': 'active',
            'progress': 3,
            'target': 7,
            'started_at': '2024-09-10',
            'expires_at': '2024-09-17'
        },
        {
            'mission_id': 2,
            'status': 'completed',
            'progress': 5,
            'target': 5,
            'started_at': '2024-09-03',
            'completed_at': '2024-09-08'
        },
        {
            'mission_id': 4,
            'status': 'active',
            'progress': 2,
            'target': 5,
            'started_at': '2024-09-12',
            'expires_at': '2024-09-26'
        }
    ]
}

@missions_bp.route('/available', methods=['GET'])
def get_available_missions():
    """Get all available sustainability missions"""
    try:
        return jsonify({
            'success': True,
            'missions': SUSTAINABILITY_MISSIONS
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@missions_bp.route('/user/<int:user_id>', methods=['GET'])
def get_user_missions(user_id):
    """Get user's active and completed missions"""
    try:
        user_missions = USER_MISSIONS.get(user_id, [])
        
        # Enrich with mission details
        enriched_missions = []
        for user_mission in user_missions:
            mission_details = next(
                (m for m in SUSTAINABILITY_MISSIONS if m['id'] == user_mission['mission_id']), 
                None
            )
            if mission_details:
                enriched_mission = {**mission_details, **user_mission}
                enriched_missions.append(enriched_mission)
        
        return jsonify({
            'success': True,
            'missions': enriched_missions
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@missions_bp.route('/start', methods=['POST'])
def start_mission():
    """Start a new sustainability mission"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        mission_id = data.get('mission_id')
        
        if not user_id or not mission_id:
            return jsonify({
                'success': False,
                'error': 'User ID and Mission ID are required'
            }), 400
        
        # Find mission details
        mission = next((m for m in SUSTAINABILITY_MISSIONS if m['id'] == mission_id), None)
        if not mission:
            return jsonify({
                'success': False,
                'error': 'Mission not found'
            }), 404
        
        # Check if user already has this mission active
        user_missions = USER_MISSIONS.get(user_id, [])
        existing_mission = next(
            (m for m in user_missions if m['mission_id'] == mission_id and m['status'] == 'active'), 
            None
        )
        
        if existing_mission:
            return jsonify({
                'success': False,
                'error': 'Mission already active'
            }), 400
        
        # Start new mission
        start_date = datetime.now()
        expire_date = start_date + timedelta(days=mission['duration_days'])
        
        new_mission = {
            'mission_id': mission_id,
            'status': 'active',
            'progress': 0,
            'target': mission.get('target', 1),
            'started_at': start_date.strftime('%Y-%m-%d'),
            'expires_at': expire_date.strftime('%Y-%m-%d')
        }
        
        if user_id not in USER_MISSIONS:
            USER_MISSIONS[user_id] = []
        
        USER_MISSIONS[user_id].append(new_mission)
        
        return jsonify({
            'success': True,
            'message': 'Mission started successfully',
            'mission': {**mission, **new_mission}
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@missions_bp.route('/progress', methods=['POST'])
def update_mission_progress():
    """Update progress on a sustainability mission"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        mission_id = data.get('mission_id')
        progress_increment = data.get('progress', 1)
        
        if not user_id or not mission_id:
            return jsonify({
                'success': False,
                'error': 'User ID and Mission ID are required'
            }), 400
        
        user_missions = USER_MISSIONS.get(user_id, [])
        mission_index = next(
            (i for i, m in enumerate(user_missions) 
             if m['mission_id'] == mission_id and m['status'] == 'active'), 
            None
        )
        
        if mission_index is None:
            return jsonify({
                'success': False,
                'error': 'Active mission not found'
            }), 404
        
        # Update progress
        mission = user_missions[mission_index]
        mission['progress'] = min(mission['progress'] + progress_increment, mission['target'])
        
        # Check if mission is completed
        if mission['progress'] >= mission['target']:
            mission['status'] = 'completed'
            mission['completed_at'] = datetime.now().strftime('%Y-%m-%d')
            
            # Find mission details for rewards
            mission_details = next(
                (m for m in SUSTAINABILITY_MISSIONS if m['id'] == mission_id), 
                None
            )
            
            if mission_details:
                return jsonify({
                    'success': True,
                    'message': 'Mission completed!',
                    'mission': {**mission_details, **mission},
                    'rewards': {
                        'points': mission_details['points_reward'],
                        'tickets': mission_details['tickets_reward']
                    }
                })
        
        return jsonify({
            'success': True,
            'message': 'Progress updated',
            'mission': mission
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@missions_bp.route('/leaderboard', methods=['GET'])
def get_missions_leaderboard():
    """Get community leaderboard for sustainability missions"""
    try:
        # Mock leaderboard data
        leaderboard = [
            {
                'user_id': 1,
                'name': 'Ahmed Al-Rashid',
                'missions_completed': 12,
                'total_points_earned': 3500,
                'rank': 1,
                'badge': 'Eco Champion'
            },
            {
                'user_id': 2,
                'name': 'Sarah Johnson',
                'missions_completed': 8,
                'total_points_earned': 2100,
                'rank': 2,
                'badge': 'Planet Hero'
            },
            {
                'user_id': 3,
                'name': 'Mohammed Hassan',
                'missions_completed': 6,
                'total_points_earned': 1800,
                'rank': 3,
                'badge': 'Green Warrior'
            }
        ]
        
        return jsonify({
            'success': True,
            'leaderboard': leaderboard
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

