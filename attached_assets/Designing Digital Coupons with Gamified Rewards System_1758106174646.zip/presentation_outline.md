# Presentation Outline: Planet Heroes Package & Digital Voucher System

## Slide 1: Title Slide
- **Main Title**: Planet Heroes Package & Digital Voucher System
- **Subtitle**: Empowering Eco-Conscious Consumers on DeliWer
- **Presenter**: Manus AI
- **Date**: September 15, 2025

## Slide 2: Introduction to Planet Heroes
- **Title**: What is Planet Heroes?
- **Content**: 
  - DeliWer's environmental community hub
  - Mission: Connect globally, share missions, multiply impact
  - Key metrics: 12,847 Planet Heroes, 2.4M Bottles Prevented, 180T CO₂ Saved

## Slide 3: The Planet Heroes Package
- **Title**: Introducing the Planet Heroes Package
- **Content**: 
  - A premium eco-friendly offering
  - Features Mazaya Center as a key location
  - Value proposition: Combine environmental impact with exclusive rewards
  - Image: `planet_heroes_coupon_main.png`

## Slide 4: AquaCafe Pro System Offer
- **Title**: AquaCafe Pro System: Pure Water, Pure Impact
- **Content**: 
  - 5-stage water purification system
  - Points: 15,000 PTS (≈ AED 1,500 value)
  - Benefits: Free installation, premium water access, reduce plastic waste
  - Image: `aquacafe_system_coupon.png`

## Slide 5: Bakers Kitchen Smoothies Offer
- **Title**: Bakers Kitchen Smoothies: Healthy & Rewarding
- **Content**: 
  - Offer: Buy one smoothie, get one free
  - Points: 3,500 PTS (≈ AED 350 value)
  - Location: Bakers Kitchen outlets in Mazaya Center
  - Image: `bakers_kitchen_smoothie_coupon.png`

## Slide 6: Gamified Planet Points System
- **Title**: Earn & Redeem: The Planet Points System
- **Content**: 
  - How it works: Earn points through device trading and environmental activities
  - Redemption: Use points for exclusive vouchers and products
  - Gamification: User levels, achievements, progress tracking
  - Real-time impact updates

## Slide 7: Digital Voucher System Overview
- **Title**: Seamless Digital Voucher Experience
- **Content**: 
  - User-friendly interface for managing and redeeming vouchers
  - Accessible via DeliWer app and website
  - Secure and trackable redemptions

## Slide 8: Referral Starter Kit Offer
- **Title**: Referral Starter Kit: AED 99 Vouchers for Two
- **Content**: 
  - Explain the AED 99 starter kit for two as a referral bonus
  - Include Pizza + Smoothie vouchers as examples
  - Image: `Pizza.jpg`, `Smothie_1.jpg`, `Smothie_2.jpg`

## Slide 9: Embeddable Widget for DeliWer Website
- **Title**: Easy Integration: The Planet Heroes Widget
- **Content**: 
  - Embeddable component for DeliWer Shopping website
  - Two modes: Full (800x600px) and Compact (320x400px)
  - Customizable themes (light/dark)
  - Simple HTML/JavaScript or React integration
  - Live demo available

## Slide 10: Terms & Conditions Highlights
- **Title**: Key Terms & Conditions
- **Content**: 
  - Offers cannot be combined
  - Valid at Mazaya Center outlets
  - Digital voucher presentation via DeliWer app
  - Validity until December 31, 2025
  - Planet Points rules (no cash value, expiry)

## Slide 10: Conclusion & Call to Action
- **Title**: Join the Movement, Make an Impact!
- **Content**: 
  - Recap: Eco-friendly rewards, gamified experience, seamless integration
  - Call to Action: Integrate the widget, promote the Planet Heroes Package
  - Contact Information: formatix@deliwer.com, +971 50 944 6936, www.deliwer.com

