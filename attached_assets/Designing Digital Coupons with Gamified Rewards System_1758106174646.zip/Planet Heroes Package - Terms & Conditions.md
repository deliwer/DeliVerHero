# Planet Heroes Package - Terms & Conditions

## General Terms
1. The Planet Heroes Package offer cannot be combined with other offers and promotions.
2. Promotion is valid at Mazaya Center outlets only for all participating merchants.
3. Digital voucher must be presented/validated at the merchant through the DeliWer app.
4. Promotion is valid until 31st December 2025.
5. Planet Points redemption is available through the DeliWer Shopping platform only.
6. For support, contact DeliWer at +971 50 944 6936 or email formatix@deliwer.com
7. DeliWer Shopping reserves the right to modify terms without prior notice.
8. Merchants reserve the right to refuse service if deemed necessary.

## AquaCafe Pro System (15,000 PTS)
- 5-stage water purification system
- Free installation (AED 299 value included)
- Valid for new customers only
- Installation must be scheduled within 30 days of redemption
- Available in Dubai delivery areas only

## Bakers Kitchen Smoothie Vouchers (3,500 PTS)
- Purchase any smoothie at regular price and get a second smoothie free
- Valid at Bakers Kitchen outlets in Mazaya Center
- Cannot be combined with other Bakers Kitchen promotions
- Valid for same-day use only
- Maximum 2 free smoothies per voucher

## Planet Points System
- Points are earned through device trading and environmental activities
- Points have no cash value and cannot be transferred
- Points expire 12 months from date of earning
- Minimum redemption varies by offer
- Points balance can be checked through DeliWer app

## Environmental Impact
- Each redemption contributes to the Planet Heroes community goal
- Impact metrics are updated monthly
- Participation helps prevent plastic bottle waste
- Contributes to CO₂ reduction initiatives

## Digital Voucher Usage
- Vouchers are delivered through the DeliWer app
- QR code must be scanned at participating merchants
- Vouchers cannot be duplicated or shared
- Lost vouchers cannot be replaced
- Valid ID may be required for redemption

## Cancellation Policy
- Vouchers can be cancelled within 24 hours of redemption
- Cancelled vouchers will have points refunded to account
- Partial redemptions are not allowed
- Refunds are processed within 5-7 business days

