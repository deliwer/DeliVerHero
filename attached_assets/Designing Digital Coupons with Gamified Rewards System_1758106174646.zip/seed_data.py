#!/usr/bin/env python3
"""
Seed script to populate the database with initial data
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.tombola import db, User, Prize, Achievement
from src.main import app
import json

def seed_prizes():
    """Seed the database with prize data"""
    prizes_data = [
        # Tier 1 Prizes (Common - 70% chance)
        {"name": "10% DeliWer Discount", "tier": 1, "probability": 25, "icon": "💰", "value": "10%", "description": "Get 10% off your next DeliWer order"},
        {"name": "Free Delivery Voucher", "tier": 1, "probability": 20, "icon": "🚚", "value": "Free", "description": "Free delivery on your next order"},
        {"name": "Free Coffee at Sven's", "tier": 1, "probability": 20, "icon": "☕", "value": "AED 15", "description": "Complimentary coffee at Sven the Bakers Kitchen"},
        {"name": "50 Bonus Planet Points", "tier": 1, "probability": 15, "icon": "⭐", "value": "50 PTS", "description": "Bonus points added to your account"},
        {"name": "Digital Badge", "tier": 1, "probability": 10, "icon": "🏆", "value": "Badge", "description": "Special achievement badge"},
        {"name": "Eco Tip Feature", "tier": 1, "probability": 10, "icon": "🌱", "value": "Feature", "description": "Your eco tip featured in community"},
        
        # Tier 2 Prizes (Rare - 25% chance)
        {"name": "AED 50 Sven's Voucher", "tier": 2, "probability": 30, "icon": "🍽️", "value": "AED 50", "description": "Dining voucher for Sven the Bakers Kitchen"},
        {"name": "AquaCafe Water Bottle", "tier": 2, "probability": 25, "icon": "💧", "value": "AED 35", "description": "Premium AquaCafe branded water bottle"},
        {"name": "AED 25 DeliWer Credit", "tier": 2, "probability": 25, "icon": "💳", "value": "AED 25", "description": "Store credit for DeliWer platform"},
        {"name": "Early Access Features", "tier": 2, "probability": 20, "icon": "🚀", "value": "Access", "description": "Beta access to new AquaCafe features"},
        
        # Tier 3 Prizes (Epic - 5% chance)
        {"name": "Dinner for Two at Sven's", "tier": 3, "probability": 40, "icon": "🍽️", "value": "AED 200", "description": "Complete dinner experience for two people"},
        {"name": "Year's Supply Water Filters", "tier": 3, "probability": 30, "icon": "💧", "value": "AED 500", "description": "12 months of AquaCafe water filters"},
        {"name": "AED 100 DeliWer Credit", "tier": 3, "probability": 20, "icon": "💰", "value": "AED 100", "description": "Premium store credit"},
        {"name": "Planet Hero Merchandise Bundle", "tier": 3, "probability": 10, "icon": "🎁", "value": "AED 150", "description": "Exclusive Planet Heroes merchandise collection"}
    ]
    
    for prize_data in prizes_data:
        existing_prize = Prize.query.filter_by(name=prize_data["name"]).first()
        if not existing_prize:
            prize = Prize(**prize_data)
            db.session.add(prize)
    
    db.session.commit()
    print(f"Seeded {len(prizes_data)} prizes")

def seed_achievements():
    """Seed the database with achievement data"""
    achievements_data = [
        {"name": "Water Saver", "description": "Saved 100L of water", "icon": "💧", "requirement_type": "water_saved", "requirement_value": 100, "reward_tickets": 2, "reward_points": 100},
        {"name": "Community Champion", "description": "Completed 5 challenges", "icon": "🏆", "requirement_type": "challenges_completed", "requirement_value": 5, "reward_tickets": 3, "reward_points": 200},
        {"name": "Eco Warrior", "description": "Prevented 50 plastic bottles", "icon": "🌱", "requirement_type": "bottles_prevented", "requirement_value": 50, "reward_tickets": 2, "reward_points": 150},
        {"name": "Lucky Winner", "description": "Won 5 tombola prizes", "icon": "🎰", "requirement_type": "prizes_won", "requirement_value": 5, "reward_tickets": 1, "reward_points": 100},
        {"name": "Referral Master", "description": "Referred 10 friends", "icon": "👥", "requirement_type": "referrals", "requirement_value": 10, "reward_tickets": 5, "reward_points": 500},
        {"name": "Sustainability Expert", "description": "Shared 20 eco tips", "icon": "📚", "requirement_type": "tips_shared", "requirement_value": 20, "reward_tickets": 3, "reward_points": 300}
    ]
    
    for achievement_data in achievements_data:
        existing_achievement = Achievement.query.filter_by(name=achievement_data["name"]).first()
        if not existing_achievement:
            achievement = Achievement(**achievement_data)
            db.session.add(achievement)
    
    db.session.commit()
    print(f"Seeded {len(achievements_data)} achievements")

def seed_test_user():
    """Create a test user for development"""
    test_user_data = {
        "name": "Ahmed Al-Rashid",
        "email": "ahmed@example.com",
        "level": "Planet Hero",
        "points": 18500,
        "tickets": 12,
        "total_tickets_earned": 47,
        "total_prizes_won": 8
    }
    
    existing_user = User.query.filter_by(email=test_user_data["email"]).first()
    if not existing_user:
        user = User(**test_user_data)
        db.session.add(user)
        db.session.commit()
        print(f"Created test user: {test_user_data['name']}")
        return user.id
    else:
        print(f"Test user already exists: {existing_user.name}")
        return existing_user.id

def main():
    """Main seeding function"""
    with app.app_context():
        print("Starting database seeding...")
        
        # Create all tables
        db.create_all()
        
        # Seed data
        seed_prizes()
        seed_achievements()
        user_id = seed_test_user()
        
        print("Database seeding completed!")
        print(f"Test user ID: {user_id}")

if __name__ == "__main__":
    main()

