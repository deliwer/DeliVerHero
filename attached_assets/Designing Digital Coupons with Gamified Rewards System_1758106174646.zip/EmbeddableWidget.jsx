import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Gift, Leaf, Droplets, Star, Trophy, Users } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

// Import images
import planetHeroesCoupon from '../assets/planet_heroes_coupon_main.png'
import bakersKitchenCoupon from '../assets/bakers_kitchen_smoothie_coupon.png'
import aquacafeCoupon from '../assets/aquacafe_system_coupon.png'
import deliwerLogo from '../assets/deliwerlogo.png'

const EmbeddableWidget = ({ 
  userPoints = 18500, 
  userLevel = 'Planet Hero',
  compact = false,
  theme = 'light'
}) => {
  const [selectedOffer, setSelectedOffer] = useState(null)
  const [showSuccess, setShowSuccess] = useState(false)
  const [currentPoints, setCurrentPoints] = useState(userPoints)

  const offers = [
    {
      id: 1,
      title: 'Planet Heroes Package',
      description: 'Complete eco-package at Mazaya Center',
      points: 18500,
      value: 'AED 1,850',
      image: planetHeroesCoupon,
      category: 'Premium',
      discount: '20% OFF'
    },
    {
      id: 2,
      title: 'AquaCafe Pro System',
      description: '5-stage water purification',
      points: 15000,
      value: 'AED 1,500',
      image: aquacafeCoupon,
      category: 'Water',
      discount: 'FREE Install'
    },
    {
      id: 3,
      title: 'Bakers Kitchen Smoothies',
      description: 'Buy 1 Get 1 Free smoothies',
      points: 3500,
      value: 'AED 350',
      image: bakersKitchenCoupon,
      category: 'Food',
      discount: 'BOGO'
    }
  ]

  const communityStats = {
    heroes: 12847,
    bottlesPrevented: 2400000,
    co2Saved: 180
  }

  const handleRedeem = (offer) => {
    if (currentPoints >= offer.points) {
      setCurrentPoints(prev => prev - offer.points)
      setSelectedOffer(offer)
      setShowSuccess(true)
      setTimeout(() => setShowSuccess(false), 3000)
    }
  }

  const formatNumber = (num) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
    return num.toString()
  }

  if (compact) {
    return (
      <div className={`w-full max-w-sm mx-auto ${theme === 'dark' ? 'dark' : ''}`}>
        <Card className="overflow-hidden">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <img src={deliwerLogo} alt="DeliWer" className="h-6 w-auto" />
              <Badge variant="secondary" className="text-xs">
                <Leaf className="w-3 h-3 mr-1" />
                {formatNumber(currentPoints)} PTS
              </Badge>
            </div>
            <CardTitle className="text-lg">Planet Heroes Rewards</CardTitle>
            <CardDescription className="text-sm">Redeem your eco-points</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {offers.slice(0, 2).map((offer) => (
              <div key={offer.id} className="flex items-center space-x-3 p-2 rounded-lg border">
                <img src={offer.image} alt={offer.title} className="w-12 h-12 object-cover rounded" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{offer.title}</p>
                  <p className="text-xs text-gray-500">{offer.points.toLocaleString()} PTS</p>
                </div>
                <Button 
                  size="sm" 
                  onClick={() => handleRedeem(offer)}
                  disabled={currentPoints < offer.points}
                  className="text-xs px-2 py-1"
                >
                  Redeem
                </Button>
              </div>
            ))}
            <Button variant="outline" className="w-full text-sm">
              View All Rewards
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className={`w-full max-w-4xl mx-auto ${theme === 'dark' ? 'dark' : ''}`}>
      <Card className="overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-green-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img src={deliwerLogo} alt="DeliWer" className="h-8 w-auto" />
              <div>
                <CardTitle className="text-xl">Planet Heroes Rewards</CardTitle>
                <CardDescription>Transform your environmental impact into rewards</CardDescription>
              </div>
            </div>
            <div className="text-right">
              <Badge variant="secondary" className="text-lg px-4 py-2 mb-2">
                <Leaf className="w-4 h-4 mr-2" />
                {formatNumber(currentPoints)} PTS
              </Badge>
              <p className="text-sm text-gray-600">{userLevel}</p>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          {/* Community Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-5 h-5 text-blue-500 mr-1" />
                <span className="font-bold text-lg">{formatNumber(communityStats.heroes)}</span>
              </div>
              <p className="text-xs text-gray-600">Planet Heroes</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Droplets className="w-5 h-5 text-blue-500 mr-1" />
                <span className="font-bold text-lg">{formatNumber(communityStats.bottlesPrevented)}</span>
              </div>
              <p className="text-xs text-gray-600">Bottles Prevented</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Leaf className="w-5 h-5 text-green-500 mr-1" />
                <span className="font-bold text-lg">{communityStats.co2Saved}T</span>
              </div>
              <p className="text-xs text-gray-600">CO₂ Saved</p>
            </div>
          </div>

          {/* Featured Offers */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {offers.map((offer) => (
              <motion.div
                key={offer.id}
                whileHover={{ scale: 1.02 }}
                className="relative"
              >
                <Card className="overflow-hidden hover:shadow-md transition-shadow">
                  <div className="relative">
                    <img 
                      src={offer.image} 
                      alt={offer.title}
                      className="w-full h-32 object-cover"
                    />
                    <Badge className="absolute top-2 right-2 text-xs" variant="secondary">
                      {offer.discount}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-sm mb-1">{offer.title}</h3>
                    <p className="text-xs text-gray-600 mb-3">{offer.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-green-600 font-bold text-sm">
                        {offer.points.toLocaleString()} PTS
                      </span>
                      <Button 
                        size="sm" 
                        onClick={() => handleRedeem(offer)}
                        disabled={currentPoints < offer.points}
                        className="text-xs px-3 py-1"
                      >
                        <Gift className="w-3 h-3 mr-1" />
                        Redeem
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Progress to Next Level */}
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Progress to Eco Champion</span>
              <span className="text-xs text-gray-600">2,500 PTS to go</span>
            </div>
            <Progress value={75} className="w-full h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Success Animation */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed bottom-4 right-4 z-50"
          >
            <Card className="bg-green-50 border-green-200">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <Gift className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Voucher Redeemed!</p>
                    <p className="text-xs text-gray-600">Check your wallet for details</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default EmbeddableWidget

