# Planet Heroes Digital Voucher System

## Project Overview

The Planet Heroes Digital Voucher System is a comprehensive gamified rewards platform designed for the DeliWer Shopping website. It features eco-friendly coupons with Mazaya Center background, AquaCafe by DeliWer offerings, and a complete planet points redemption system.

## Key Features

### 🎨 Custom Coupon Designs
- **Planet Heroes Package**: Complete eco-package featuring Mazaya Center background
- **AquaCafe Pro System**: 5-stage water purification system (15,000 PTS)
- **Bakers Kitchen Smoothies**: Buy-one-get-one-free smoothie vouchers (3,500 PTS)
- All designs feature Mazaya Center backgrounds and DeliWer branding

### 🎮 Gamified Planet Points System
- Real-time points tracking and redemption
- Environmental impact visualization (bottles prevented, CO₂ saved)
- Achievement system with unlockable badges
- Community stats integration (12,847 Planet Heroes, 2.4M bottles prevented)
- Progress tracking toward next level

### 🔧 Embeddable Widget System
- **Full Widget**: Complete voucher interface (800px × 600px)
- **Compact Widget**: Sidebar-friendly version (320px × 400px)
- Light and dark theme support
- Responsive design for all devices
- Easy JavaScript integration

## Technical Implementation

### Frontend Application
- **Framework**: React 18 with Vite
- **UI Components**: shadcn/ui with Tailwind CSS
- **Icons**: Lucide React
- **Animations**: Framer Motion
- **Responsive**: Mobile-first design approach

### Embeddable Widget
- **Standalone JavaScript**: No dependencies required
- **CDN Ready**: Optimized for content delivery networks
- **API Integration**: RESTful endpoint support
- **Event System**: Custom events for redemption tracking
- **Configuration**: Flexible options for customization

## File Structure

```
planet-heroes-voucher/
├── src/
│   ├── components/
│   │   ├── EmbeddableWidget.jsx    # Reusable widget component
│   │   └── WidgetDemo.jsx          # Configuration demo interface
│   ├── assets/                     # Images and static files
│   └── App.jsx                     # Main application
├── public/
│   ├── widget.js                   # Standalone widget script
│   └── widget-demo.html           # Integration demo page
└── dist/                          # Built application files
```

## Integration Guide

### HTML/JavaScript Integration

```html
<!-- Planet Heroes Widget -->
<div id="planet-heroes-widget"></div>
<script>
  window.PlanetHeroesConfig = {
    userPoints: 18500,
    userLevel: "Planet Hero",
    compact: false,
    theme: "light",
    containerId: "planet-heroes-widget"
  };
</script>
<script src="https://cdn.deliwer.com/widgets/planet-heroes.js"></script>
```

### React Component Integration

```jsx
import EmbeddableWidget from './components/EmbeddableWidget'

function App() {
  return (
    <EmbeddableWidget
      userPoints={18500}
      userLevel="Planet Hero"
      compact={false}
      theme="light"
    />
  )
}
```

### Configuration Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `userPoints` | number | 18500 | User's current planet points |
| `userLevel` | string | "Planet Hero" | User's current level |
| `compact` | boolean | false | Use compact layout |
| `theme` | string | "light" | Theme: "light" or "dark" |
| `containerId` | string | "planet-heroes-widget" | Container element ID |
| `apiEndpoint` | string | null | Optional API endpoint |

## JavaScript API

### Methods

```javascript
// Update user points
PlanetHeroesWidget.updatePoints(20000);

// Get current points
const points = PlanetHeroesWidget.getPoints();

// Refresh widget
PlanetHeroesWidget.refresh();
```

### Events

```javascript
// Listen for redemption events
window.addEventListener('planetHeroesRedemption', function(event) {
  console.log('Voucher redeemed:', event.detail.offer);
  console.log('Remaining points:', event.detail.remainingPoints);
});
```

## Coupon Details

### Planet Heroes Package (18,500 PTS)
- **Value**: AED 1,850
- **Includes**: AquaCafe Pro System, Bakers Kitchen Vouchers, Environmental Impact Tracking
- **Location**: Mazaya Center outlets
- **Validity**: Until December 31, 2025

### AquaCafe Pro System (15,000 PTS)
- **Value**: AED 1,500
- **Features**: 5-stage water purification system
- **Includes**: Free installation (AED 299 value), 1-year warranty
- **Delivery**: Dubai areas only

### Bakers Kitchen Smoothies (3,500 PTS)
- **Value**: AED 350
- **Offer**: Buy one smoothie, get one free
- **Location**: Bakers Kitchen outlets in Mazaya Center
- **Validity**: Same-day use only

## Terms & Conditions

### General Terms
1. Offers cannot be combined with other promotions
2. Valid at Mazaya Center outlets only
3. Digital voucher must be presented via DeliWer app
4. Valid until December 31, 2025
5. Points redemption through DeliWer Shopping platform only

### Planet Points System
- Points earned through device trading and environmental activities
- Points have no cash value and cannot be transferred
- Points expire 12 months from earning date
- Minimum redemption varies by offer

### Environmental Impact
- Each redemption contributes to Planet Heroes community goals
- Impact metrics updated monthly
- Participation helps prevent plastic bottle waste
- Contributes to CO₂ reduction initiatives

## Deployment

### Production Build
```bash
cd planet-heroes-voucher
npm run build
```

### Static Deployment
The `dist/` folder contains all files needed for static hosting:
- `index.html` - Main application
- `assets/` - Optimized CSS, JS, and images
- Copy to any web server or CDN

### Widget Deployment
1. Upload `widget.js` to CDN
2. Update script src in integration code
3. Configure API endpoints if needed
4. Test integration on target website

## Browser Support

- **Modern Browsers**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
- **Mobile**: iOS Safari 14+, Chrome Mobile 90+
- **Features**: ES6+, CSS Grid, Flexbox, Fetch API

## Performance

- **Bundle Size**: ~383KB (121KB gzipped)
- **Load Time**: <2s on 3G networks
- **Widget Size**: ~50KB standalone
- **Images**: Optimized PNG format

## Security

- **XSS Protection**: Content Security Policy headers recommended
- **API Security**: HTTPS endpoints only
- **Data Privacy**: No personal data stored in widget
- **CORS**: Configured for cross-origin requests

## Support & Maintenance

### Contact Information
- **Email**: formatix@deliwer.com
- **Phone**: +971 50 944 6936
- **Website**: www.deliwer.com

### Updates
- Widget auto-updates via CDN
- Version tracking through API
- Backward compatibility maintained
- Migration guides provided for major updates

## Analytics & Tracking

### Redemption Tracking
```javascript
// Track redemptions
window.addEventListener('planetHeroesRedemption', function(event) {
  // Send to analytics platform
  gtag('event', 'voucher_redemption', {
    'voucher_type': event.detail.offer.title,
    'points_spent': event.detail.offer.points,
    'remaining_points': event.detail.remainingPoints
  });
});
```

### Performance Monitoring
- Widget load times
- Redemption success rates
- User engagement metrics
- Error tracking and reporting

## Future Enhancements

### Planned Features
- Push notifications for new offers
- Social sharing capabilities
- Referral program integration
- Advanced analytics dashboard
- Multi-language support

### API Roadmap
- Real-time points synchronization
- Inventory management integration
- Merchant portal access
- Advanced reporting features

## Troubleshooting

### Common Issues

**Widget not loading**
- Check script URL and network connectivity
- Verify container element exists
- Check browser console for errors

**Points not updating**
- Verify API endpoint configuration
- Check authentication tokens
- Confirm user permissions

**Styling conflicts**
- Use CSS specificity or !important
- Check for conflicting stylesheets
- Consider iframe isolation

### Debug Mode
```javascript
window.PlanetHeroesConfig = {
  debug: true,  // Enable console logging
  // ... other options
};
```

## License & Usage

This Planet Heroes Digital Voucher System is proprietary software developed for DeliWer Shopping FZCO. All rights reserved. Unauthorized reproduction or distribution is prohibited.

For licensing inquiries, contact: formatix@deliwer.com

