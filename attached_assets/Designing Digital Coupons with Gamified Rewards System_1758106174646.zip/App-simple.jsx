import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Droplets, 
  Gift, 
  Star, 
  Users, 
  Leaf, 
  Trophy, 
  Ticket, 
  Play, 
  Award,
  Menu,
  X,
  Sparkles,
  Target,
  Zap
} from 'lucide-react'
import './App.css'

// Import assets
import deliwerLogo from './assets/deliwerlogo.png'
import planetHeroesCoupon from './assets/planet_heroes_coupon_main.png'
import aquacafeCoupon from './assets/aquacafe_system_coupon.png'
import bakersKitchenCoupon from './assets/bakers_kitchen_smoothie_coupon.png'

// API Configuration
const API_BASE_URL = 'http://localhost:5000/api'

// API Functions
const api = {
  getUser: async (userId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/tombola/user/${userId}`)
      return response.json()
    } catch (error) {
      console.error('API Error:', error)
      return { success: false, error: error.message }
    }
  },
  
  spinTombola: async (userId, tickets = 1) => {
    try {
      const response = await fetch(`${API_BASE_URL}/tombola/spin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_id: userId, tickets })
      })
      return response.json()
    } catch (error) {
      console.error('API Error:', error)
      return { success: false, error: error.message }
    }
  },
  
  getUserAchievements: async (userId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/tombola/user/${userId}/achievements`)
      return response.json()
    } catch (error) {
      console.error('API Error:', error)
      return { success: false, error: error.message }
    }
  },
  
  getCommunityStats: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/tombola/stats`)
      return response.json()
    } catch (error) {
      console.error('API Error:', error)
      return { success: false, error: error.message }
    }
  }
}

// Mock user ID for demo
const DEMO_USER_ID = 1

function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [user, setUser] = useState(null)
  const location = useLocation()

  useEffect(() => {
    const fetchUser = async () => {
      const userData = await api.getUser(DEMO_USER_ID)
      if (userData.success) {
        setUser(userData.user)
      }
    }
    fetchUser()
  }, [])

  const navItems = [
    { path: '/', label: 'Dashboard' },
    { path: '/tombola', label: 'Tombola' },
    { path: '/rewards', label: 'Rewards' },
    { path: '/community', label: 'Community' },
    { path: '/profile', label: 'Profile' }
  ]

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-3">
              <img src={deliwerLogo} alt="DeliWer" className="h-8 w-auto" />
              <span className="text-xl font-bold text-emerald-600">AquaCafe Tombola</span>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location.pathname === item.path
                    ? 'bg-emerald-100 text-emerald-700'
                    : 'text-gray-600 hover:text-emerald-600 hover:bg-emerald-50'
                }`}
              >
                {item.label}
              </Link>
            ))}
            <div className="flex items-center space-x-2 bg-emerald-50 px-3 py-2 rounded-lg">
              <Ticket className="h-4 w-4 text-emerald-600" />
              <span className="text-sm font-medium text-emerald-700">{user ? `${user.tickets} tickets` : '...'}</span>
            </div>
          </div>

          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-600 hover:text-emerald-600 p-2"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`block px-3 py-2 rounded-md text-base font-medium transition-colors ${
                    location.pathname === item.path
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'text-gray-600 hover:text-emerald-600 hover:bg-emerald-50'
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

function Dashboard() {
  const [user, setUser] = useState(null)
  const [communityStats, setCommunityStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const userData = await api.getUser(DEMO_USER_ID)
      if (userData.success) {
        setUser(userData.user)
      }

      const statsData = await api.getCommunityStats()
      if (statsData.success) {
        setCommunityStats(statsData.stats)
      }

      setLoading(false)
    }
    fetchData()
  }, [])

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user?.name || 'Planet Hero'}! 🌟
          </h1>
          <p className="text-gray-600">
            You're making a real difference for our planet. Keep up the amazing work!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Available Tickets</CardTitle>
              <Ticket className="h-4 w-4 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600">{user?.tickets || 0}</div>
              <p className="text-xs text-muted-foreground">Ready to play!</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Planet Points</CardTitle>
              <Star className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{user?.points?.toLocaleString() || 0}</div>
              <p className="text-xs text-muted-foreground">Current level: {user?.level || 'Planet Hero'}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Prizes Won</CardTitle>
              <Trophy className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{user?.total_prizes_won || 0}</div>
              <p className="text-xs text-muted-foreground">From {user?.total_tickets_earned || 0} tickets earned</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Community Impact</CardTitle>
              <Leaf className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{communityStats?.bottles_prevented?.toLocaleString() || 0}</div>
              <p className="text-xs text-muted-foreground">Bottles prevented</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Play className="h-5 w-5 text-emerald-600" />
                <span>Play Tombola</span>
              </CardTitle>
              <CardDescription>
                Use your tickets to win amazing prizes and support sustainability!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Available tickets:</span>
                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                    {user?.tickets || 0} tickets
                  </Badge>
                </div>
                <Link to="/tombola">
                  <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                    <Sparkles className="h-4 w-4 mr-2" />
                    Play Now
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Gift className="h-5 w-5 text-blue-600" />
                <span>Your Rewards</span>
              </CardTitle>
              <CardDescription>
                Check your prizes and redeem vouchers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Planet Points:</span>
                  <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                    {user?.points?.toLocaleString() || 0} PTS
                  </Badge>
                </div>
                <Link to="/rewards">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    <Gift className="h-4 w-4 mr-2" />
                    View Rewards
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function TombolaGame() {
  const [isSpinning, setIsSpinning] = useState(false)
  const [spinResult, setSpinResult] = useState(null)
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const userData = await api.getUser(DEMO_USER_ID)
      if (userData.success) {
        setUser(userData.user)
      }
      setLoading(false)
    }
    fetchData()
  }, [])

  const handleSpin = async () => {
    if (!user || user.tickets <= 0) return

    setIsSpinning(true)
    setSpinResult(null)

    const result = await api.spinTombola(DEMO_USER_ID)

    if (result.success) {
      setSpinResult(result.spin_result)
      setUser(result.user)
      setTimeout(() => {
        setIsSpinning(false)
      }, 2000)
    } else {
      setIsSpinning(false)
      alert('Spin failed: ' + result.error)
    }
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">🎰 Planet Heroes Tombola</h1>
          <p className="text-xl text-gray-600 mb-6">
            Spin the wheel and win amazing prizes while supporting sustainability!
          </p>
          <div className="flex items-center justify-center space-x-4">
            <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 text-lg px-4 py-2">
              <Ticket className="h-5 w-5 mr-2" />
              {user ? `${user.tickets} tickets available` : 'Loading...'}
            </Badge>
          </div>
        </div>

        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="text-center">Tombola Wheel</CardTitle>
            <CardDescription className="text-center">
              Click spin to use 1 ticket and win a prize!
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="w-48 h-48 mx-auto bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
              {isSpinning ? (
                <div className="animate-spin text-6xl">🎰</div>
              ) : (
                <div className="text-6xl">🎯</div>
              )}
            </div>

            <Button 
              onClick={handleSpin} 
              disabled={isSpinning || !user || user.tickets <= 0} 
              className="w-full bg-purple-600 hover:bg-purple-700 text-lg py-3"
            >
              {isSpinning ? "Spinning..." : user && user.tickets > 0 ? "Spin for 1 Ticket" : "No Tickets"}
            </Button>

            {spinResult && !isSpinning && (
              <Card className="bg-yellow-50 border-yellow-200">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-4xl mb-2">{spinResult.prize_icon}</div>
                    <h3 className="text-lg font-bold text-yellow-800 mb-2">
                      Congratulations! You won:
                    </h3>
                    <p className="text-xl font-semibold text-yellow-700 mb-2">
                      {spinResult.prize_name}
                    </p>
                    <Badge className="bg-yellow-200 text-yellow-800">
                      Tier {spinResult.tier} Prize
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function RewardsPage() {
  const [vouchers, setVouchers] = useState([])
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchRewardsData = async () => {
      try {
        const userData = await api.getUser(DEMO_USER_ID)
        if (userData.success) {
          setUser(userData.user)
        }

        const vouchersResponse = await fetch(`${API_BASE_URL}/tombola/rewards/vouchers`)
        const vouchersData = await vouchersResponse.json()
        if (vouchersData.success) {
          setVouchers(vouchersData.vouchers)
        }

        setLoading(false)
      } catch (error) {
        console.error('Error fetching rewards data:', error)
        setLoading(false)
      }
    }

    fetchRewardsData()
  }, [])

  const handleRedeemVoucher = async (voucherId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/tombola/rewards/redeem`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: DEMO_USER_ID,
          voucher_id: voucherId
        })
      })

      const data = await response.json()
      if (data.success) {
        setUser(data.user)
        alert(data.message)
      } else {
        alert(data.error)
      }
    } catch (error) {
      console.error('Error redeeming voucher:', error)
      alert('Failed to redeem voucher')
    }
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading rewards...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-emerald-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">🎁 Your Rewards</h1>
          <p className="text-xl text-gray-600">
            Redeem your Planet Points and enjoy exclusive benefits
          </p>
          {user && (
            <div className="mt-4">
              <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-lg px-4 py-2">
                <Star className="h-5 w-5 mr-2" />
                {user.points.toLocaleString()} Planet Points Available
              </Badge>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vouchers.map((voucher) => (
            <Card key={voucher.id}>
              <CardHeader>
                <img 
                  src={voucher.id === 1 ? planetHeroesCoupon : voucher.id === 2 ? aquacafeCoupon : bakersKitchenCoupon} 
                  alt={voucher.name} 
                  className="w-full h-48 object-cover rounded-lg" 
                />
              </CardHeader>
              <CardContent>
                <CardTitle className="mb-2">{voucher.name}</CardTitle>
                <CardDescription className="mb-4">
                  {voucher.description}
                </CardDescription>
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className={
                    voucher.category === 'package' ? 'bg-emerald-100 text-emerald-700' :
                    voucher.category === 'product' ? 'bg-blue-100 text-blue-700' :
                    'bg-orange-100 text-orange-700'
                  }>
                    {voucher.points_required.toLocaleString()} PTS
                  </Badge>
                  <Button 
                    size="sm" 
                    className="bg-emerald-600 hover:bg-emerald-700"
                    onClick={() => handleRedeemVoucher(voucher.id)}
                    disabled={!user || user.points < voucher.points_required}
                  >
                    {!user || user.points < voucher.points_required ? 'Insufficient Points' : 'Redeem'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

function CommunityPage() {
  const [communityStats, setCommunityStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const statsData = await api.getCommunityStats()
      if (statsData.success) {
        setCommunityStats(statsData.stats)
      }
      setLoading(false)
    }
    fetchData()
  }, [])

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">🌍 Planet Heroes Community</h1>
          <p className="text-xl text-gray-600">
            Join thousands of eco-warriors making a difference together
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Community Impact</CardTitle>
            <CardDescription>Our collective environmental achievements</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">{communityStats?.bottles_prevented?.toLocaleString() || 0}</div>
                <div className="text-sm text-gray-600">Plastic Bottles Prevented</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{communityStats?.co2_saved_kg || 0}kg</div>
                <div className="text-sm text-gray-600">CO₂ Saved</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">{communityStats?.total_users || 0}</div>
                <div className="text-sm text-gray-600">Active Members</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">{communityStats?.total_prizes_won || 0}</div>
                <div className="text-sm text-gray-600">Prizes Won</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function ProfilePage() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchUserData = async () => {
      const userData = await api.getUser(DEMO_USER_ID)
      if (userData.success) {
        setUser(userData.user)
      }
      setLoading(false)
    }

    fetchUserData()
  }, [])

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading profile...</div>
  }

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">User not found</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">👤 Your Profile</h1>
          <p className="text-xl text-gray-600">
            Manage your Planet Heroes account and preferences
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
            <CardDescription>Your personal details and membership status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Full Name</label>
                <p className="text-lg">{user.name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Member Level</label>
                <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 ml-2">
                  {user.level}
                </Badge>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Planet Points</label>
                <p className="text-lg font-bold text-blue-600">{user.points.toLocaleString()}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Available Tickets</label>
                <p className="text-lg font-bold text-emerald-600">{user.tickets}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Navigation />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/tombola" element={<TombolaGame />} />
          <Route path="/rewards" element={<RewardsPage />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/profile" element={<ProfilePage />} />
        </Routes>
      </div>
    </Router>
  )
}

export default App

