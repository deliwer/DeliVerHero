/**
 * Planet Heroes Widget - Embeddable Voucher System
 * For DeliWer Shopping Website Integration
 */

(function() {
  'use strict';

  // Default configuration
  const defaultConfig = {
    userPoints: 18500,
    userLevel: 'Planet Hero',
    compact: false,
    theme: 'light',
    containerId: 'planet-heroes-widget',
    apiEndpoint: 'https://api.deliwer.com/planet-heroes'
  };

  // Merge user config with defaults
  const config = Object.assign({}, defaultConfig, window.PlanetHeroesConfig || {});

  // Widget data
  const offers = [
    {
      id: 1,
      title: 'Planet Heroes Package',
      description: 'Complete eco-package at Mazaya Center',
      points: 18500,
      value: 'AED 1,850',
      category: 'Premium',
      discount: '20% OFF',
      image: 'https://cdn.deliwer.com/images/planet-heroes-package.png'
    },
    {
      id: 2,
      title: 'AquaCafe Pro System',
      description: '5-stage water purification',
      points: 15000,
      value: 'AED 1,500',
      category: 'Water',
      discount: 'FREE Install',
      image: 'https://cdn.deliwer.com/images/aquacafe-system.png'
    },
    {
      id: 3,
      title: 'Bakers Kitchen Smoothies',
      description: 'Buy 1 Get 1 Free smoothies',
      points: 3500,
      value: 'AED 350',
      category: 'Food',
      discount: 'BOGO',
      image: 'https://cdn.deliwer.com/images/bakers-kitchen-smoothies.png'
    }
  ];

  const communityStats = {
    heroes: 12847,
    bottlesPrevented: 2400000,
    co2Saved: 180
  };

  // Utility functions
  function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  }

  function createElement(tag, className, innerHTML) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (innerHTML) element.innerHTML = innerHTML;
    return element;
  }

  // CSS Styles
  const styles = `
    .planet-heroes-widget {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: ${config.compact ? '320px' : '800px'};
      margin: 0 auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }
    
    .planet-heroes-widget.dark {
      background: #1f2937;
      color: white;
    }
    
    .widget-header {
      background: linear-gradient(135deg, #dbeafe 0%, #dcfce7 100%);
      padding: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .widget-title {
      font-size: ${config.compact ? '16px' : '20px'};
      font-weight: 600;
      margin: 0;
    }
    
    .widget-points {
      background: #f3f4f6;
      padding: 8px 12px;
      border-radius: 20px;
      font-size: 14px;
      font-weight: 600;
      color: #059669;
    }
    
    .widget-content {
      padding: 16px;
    }
    
    .community-stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      margin-bottom: 20px;
      text-align: center;
    }
    
    .stat-item {
      padding: 12px;
    }
    
    .stat-value {
      font-size: 18px;
      font-weight: 700;
      color: #059669;
    }
    
    .stat-label {
      font-size: 12px;
      color: #6b7280;
      margin-top: 4px;
    }
    
    .offers-grid {
      display: grid;
      grid-template-columns: ${config.compact ? '1fr' : 'repeat(auto-fit, minmax(250px, 1fr))'};
      gap: 16px;
    }
    
    .offer-card {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .offer-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px -8px rgba(0, 0, 0, 0.15);
    }
    
    .offer-image {
      width: 100%;
      height: ${config.compact ? '80px' : '120px'};
      object-fit: cover;
    }
    
    .offer-content {
      padding: 12px;
    }
    
    .offer-title {
      font-size: 14px;
      font-weight: 600;
      margin: 0 0 4px 0;
    }
    
    .offer-description {
      font-size: 12px;
      color: #6b7280;
      margin: 0 0 12px 0;
    }
    
    .offer-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .offer-points {
      font-size: 14px;
      font-weight: 600;
      color: #059669;
    }
    
    .redeem-btn {
      background: #059669;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 12px;
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .redeem-btn:hover {
      background: #047857;
    }
    
    .redeem-btn:disabled {
      background: #d1d5db;
      cursor: not-allowed;
    }
    
    .success-message {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #10b981;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 14px;
      z-index: 1000;
      animation: slideIn 0.3s ease-out;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    .compact-offer {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 8px;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      margin-bottom: 8px;
    }
    
    .compact-offer img {
      width: 40px;
      height: 40px;
      border-radius: 4px;
      object-fit: cover;
    }
    
    .compact-offer-info {
      flex: 1;
      min-width: 0;
    }
    
    .compact-offer-title {
      font-size: 12px;
      font-weight: 600;
      margin: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .compact-offer-points {
      font-size: 10px;
      color: #6b7280;
      margin: 2px 0 0 0;
    }
  `;

  // Create and inject styles
  function injectStyles() {
    const styleSheet = document.createElement('style');
    styleSheet.textContent = styles;
    document.head.appendChild(styleSheet);
  }

  // Show success message
  function showSuccess(offerTitle) {
    const message = createElement('div', 'success-message', 
      `✅ ${offerTitle} voucher redeemed successfully!`);
    document.body.appendChild(message);
    
    setTimeout(() => {
      if (message.parentNode) {
        message.parentNode.removeChild(message);
      }
    }, 3000);
  }

  // Handle redemption
  function handleRedeem(offer) {
    if (config.userPoints >= offer.points) {
      // Update points
      config.userPoints -= offer.points;
      updatePointsDisplay();
      
      // Show success message
      showSuccess(offer.title);
      
      // Call API if endpoint is configured
      if (config.apiEndpoint) {
        fetch(`${config.apiEndpoint}/redeem`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ offerId: offer.id, points: offer.points })
        }).catch(console.error);
      }
      
      // Trigger custom event
      window.dispatchEvent(new CustomEvent('planetHeroesRedemption', {
        detail: { offer, remainingPoints: config.userPoints }
      }));
    }
  }

  // Update points display
  function updatePointsDisplay() {
    const pointsElement = document.querySelector('.widget-points');
    if (pointsElement) {
      pointsElement.textContent = `🌱 ${formatNumber(config.userPoints)} PTS`;
    }
  }

  // Create compact widget
  function createCompactWidget() {
    const widget = createElement('div', `planet-heroes-widget ${config.theme}`);
    
    const header = createElement('div', 'widget-header');
    header.innerHTML = `
      <div>
        <h3 class="widget-title">Planet Heroes Rewards</h3>
        <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280;">Redeem your eco-points</p>
      </div>
      <div class="widget-points">🌱 ${formatNumber(config.userPoints)} PTS</div>
    `;
    
    const content = createElement('div', 'widget-content');
    
    // Show top 2 offers in compact mode
    const topOffers = offers.slice(0, 2);
    topOffers.forEach(offer => {
      const offerElement = createElement('div', 'compact-offer');
      offerElement.innerHTML = `
        <img src="${offer.image}" alt="${offer.title}" onerror="this.style.display='none'">
        <div class="compact-offer-info">
          <h4 class="compact-offer-title">${offer.title}</h4>
          <p class="compact-offer-points">${offer.points.toLocaleString()} PTS</p>
        </div>
        <button class="redeem-btn" ${config.userPoints < offer.points ? 'disabled' : ''}>
          Redeem
        </button>
      `;
      
      const button = offerElement.querySelector('.redeem-btn');
      button.addEventListener('click', () => handleRedeem(offer));
      
      content.appendChild(offerElement);
    });
    
    // View all button
    const viewAllBtn = createElement('button', 'redeem-btn', 'View All Rewards');
    viewAllBtn.style.width = '100%';
    viewAllBtn.style.marginTop = '8px';
    content.appendChild(viewAllBtn);
    
    widget.appendChild(header);
    widget.appendChild(content);
    
    return widget;
  }

  // Create full widget
  function createFullWidget() {
    const widget = createElement('div', `planet-heroes-widget ${config.theme}`);
    
    const header = createElement('div', 'widget-header');
    header.innerHTML = `
      <div>
        <h3 class="widget-title">Planet Heroes Rewards</h3>
        <p style="margin: 4px 0 0 0; font-size: 14px; color: #6b7280;">Transform your environmental impact into rewards</p>
      </div>
      <div>
        <div class="widget-points">🌱 ${formatNumber(config.userPoints)} PTS</div>
        <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280; text-align: right;">${config.userLevel}</p>
      </div>
    `;
    
    const content = createElement('div', 'widget-content');
    
    // Community stats
    const statsGrid = createElement('div', 'community-stats');
    statsGrid.innerHTML = `
      <div class="stat-item">
        <div class="stat-value">${formatNumber(communityStats.heroes)}</div>
        <div class="stat-label">Planet Heroes</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${formatNumber(communityStats.bottlesPrevented)}</div>
        <div class="stat-label">Bottles Prevented</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${communityStats.co2Saved}T</div>
        <div class="stat-label">CO₂ Saved</div>
      </div>
    `;
    
    // Offers grid
    const offersGrid = createElement('div', 'offers-grid');
    offers.forEach(offer => {
      const offerCard = createElement('div', 'offer-card');
      offerCard.innerHTML = `
        <img src="${offer.image}" alt="${offer.title}" class="offer-image" onerror="this.style.display='none'">
        <div class="offer-content">
          <h4 class="offer-title">${offer.title}</h4>
          <p class="offer-description">${offer.description}</p>
          <div class="offer-footer">
            <span class="offer-points">${offer.points.toLocaleString()} PTS</span>
            <button class="redeem-btn" ${config.userPoints < offer.points ? 'disabled' : ''}>
              🎁 Redeem
            </button>
          </div>
        </div>
      `;
      
      const button = offerCard.querySelector('.redeem-btn');
      button.addEventListener('click', () => handleRedeem(offer));
      
      offersGrid.appendChild(offerCard);
    });
    
    content.appendChild(statsGrid);
    content.appendChild(offersGrid);
    widget.appendChild(header);
    widget.appendChild(content);
    
    return widget;
  }

  // Initialize widget
  function init() {
    // Inject styles
    injectStyles();
    
    // Find container
    const container = document.getElementById(config.containerId);
    if (!container) {
      console.error(`Planet Heroes Widget: Container with ID "${config.containerId}" not found`);
      return;
    }
    
    // Create widget
    const widget = config.compact ? createCompactWidget() : createFullWidget();
    
    // Clear container and append widget
    container.innerHTML = '';
    container.appendChild(widget);
    
    // Expose API
    window.PlanetHeroesWidget = {
      updatePoints: (points) => {
        config.userPoints = points;
        updatePointsDisplay();
      },
      getPoints: () => config.userPoints,
      refresh: () => {
        container.innerHTML = '';
        container.appendChild(config.compact ? createCompactWidget() : createFullWidget());
      }
    };
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();

