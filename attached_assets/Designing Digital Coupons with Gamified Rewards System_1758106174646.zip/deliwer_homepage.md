Trade iPhones for premium water benefits responsibly, earn Planet Points, and redeem in the AquaCafe.

### 🎁 Premium Products

iPhone 17 Pro Max

Latest flagship

45,000 PTS

≈ AED 4,500 value

🔥 Most Popular

NEW

AquaCafe Pro System

5-stage purification

15,000 PTS

≈ AED 1,500 value

💧 Essential

Baker's Kitchen

Dining vouchers

3,500 PTS

≈ AED 350 value

### ⚡ Instant Benefits

Points → Products

Transform earned points

Free Delivery

Direct to your home

Track Impact

Measure your contribution

### 🚀 Start Today

AED 99

Starter Kit Gateway

FREE Installation (AED 299 value)

Immediate point earning

Premium water access

Partnership benefits

Hero status unlocked

