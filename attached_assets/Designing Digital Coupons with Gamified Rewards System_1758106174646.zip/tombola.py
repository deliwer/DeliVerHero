from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    level = db.Column(db.String(50), default='Planet Hero')
    points = db.Column(db.Integer, default=0)
    tickets = db.Column(db.Integer, default=0)
    total_tickets_earned = db.Column(db.Integer, default=0)
    total_prizes_won = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    ticket_transactions = db.relationship('TicketTransaction', backref='user', lazy=True)
    tombola_spins = db.relationship('TombolaSpin', backref='user', lazy=True)
    prizes_won = db.relationship('PrizeWon', backref='user', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'level': self.level,
            'points': self.points,
            'tickets': self.tickets,
            'total_tickets_earned': self.total_tickets_earned,
            'total_prizes_won': self.total_prizes_won,
            'created_at': self.created_at.isoformat()
        }

class TicketTransaction(db.Model):
    __tablename__ = 'ticket_transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    tickets_earned = db.Column(db.Integer, nullable=False)
    activity_type = db.Column(db.String(50), nullable=False)  # 'water_saving', 'referral', 'dining', etc.
    activity_details = db.Column(db.Text)  # JSON string with additional details
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'tickets_earned': self.tickets_earned,
            'activity_type': self.activity_type,
            'activity_details': json.loads(self.activity_details) if self.activity_details else {},
            'created_at': self.created_at.isoformat()
        }

class Prize(db.Model):
    __tablename__ = 'prizes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    tier = db.Column(db.Integer, nullable=False)  # 1, 2, or 3
    probability = db.Column(db.Float, nullable=False)  # Probability within tier
    icon = db.Column(db.String(10), nullable=False)  # Emoji icon
    description = db.Column(db.Text)
    value = db.Column(db.String(50))  # e.g., "AED 50", "10%", etc.
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    prizes_won = db.relationship('PrizeWon', backref='prize', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'tier': self.tier,
            'probability': self.probability,
            'icon': self.icon,
            'description': self.description,
            'value': self.value,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat()
        }

class TombolaSpin(db.Model):
    __tablename__ = 'tombola_spins'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    tickets_used = db.Column(db.Integer, default=1)
    spin_result = db.Column(db.Text)  # JSON string with spin details
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'tickets_used': self.tickets_used,
            'spin_result': json.loads(self.spin_result) if self.spin_result else {},
            'created_at': self.created_at.isoformat()
        }

class PrizeWon(db.Model):
    __tablename__ = 'prizes_won'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    prize_id = db.Column(db.Integer, db.ForeignKey('prizes.id'), nullable=False)
    tombola_spin_id = db.Column(db.Integer, db.ForeignKey('tombola_spins.id'), nullable=False)
    is_redeemed = db.Column(db.Boolean, default=False)
    redeemed_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    tombola_spin = db.relationship('TombolaSpin', backref='prizes_won', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'prize_id': self.prize_id,
            'tombola_spin_id': self.tombola_spin_id,
            'is_redeemed': self.is_redeemed,
            'redeemed_at': self.redeemed_at.isoformat() if self.redeemed_at else None,
            'created_at': self.created_at.isoformat(),
            'prize': self.prize.to_dict() if self.prize else None
        }

class Achievement(db.Model):
    __tablename__ = 'achievements'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    icon = db.Column(db.String(10), nullable=False)
    requirement_type = db.Column(db.String(50), nullable=False)  # 'water_saved', 'referrals', 'prizes_won', etc.
    requirement_value = db.Column(db.Integer, nullable=False)
    reward_tickets = db.Column(db.Integer, default=0)
    reward_points = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            'requirement_type': self.requirement_type,
            'requirement_value': self.requirement_value,
            'reward_tickets': self.reward_tickets,
            'reward_points': self.reward_points,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat()
        }

class UserAchievement(db.Model):
    __tablename__ = 'user_achievements'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    achievement_id = db.Column(db.Integer, db.ForeignKey('achievements.id'), nullable=False)
    unlocked_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='user_achievements', lazy=True)
    achievement = db.relationship('Achievement', backref='user_achievements', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'achievement_id': self.achievement_id,
            'unlocked_at': self.unlocked_at.isoformat(),
            'achievement': self.achievement.to_dict() if self.achievement else None
        }

