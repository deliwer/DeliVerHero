from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
import random

membership_bp = Blueprint('membership', __name__)

# Membership tiers and benefits
MEMBERSHIP_TIERS = {
    'basic': {
        'name': 'Planet Hero',
        'price': 0,
        'benefits': [
            'Access to tombola game',
            'Basic rewards redemption',
            'Community features'
        ],
        'monthly_tickets': 5,
        'points_multiplier': 1.0
    },
    'premium': {
        'name': 'Eco Champion',
        'price': 99,  # AED 99
        'benefits': [
            'All Planet Hero benefits',
            'Double tombola tickets',
            'Exclusive premium rewards',
            'Priority customer support',
            'Monthly sustainability kit',
            'VIP community events'
        ],
        'monthly_tickets': 15,
        'points_multiplier': 1.5
    },
    'elite': {
        'name': 'Planet Guardian',
        'price': 199,  # AED 199
        'benefits': [
            'All Eco Champion benefits',
            'Triple tombola tickets',
            'Exclusive elite rewards',
            'Personal sustainability coach',
            'Premium sustainability kit',
            'Private community access'
        ],
        'monthly_tickets': 25,
        'points_multiplier': 2.0
    }
}

# Mock user memberships
USER_MEMBERSHIPS = {
    1: {
        'tier': 'premium',
        'status': 'active',
        'started_at': '2024-08-01',
        'expires_at': '2025-08-01',
        'auto_renew': True,
        'payment_method': 'credit_card',
        'total_savings': 450.75,  # AED saved through rewards
        'carbon_offset': 125.5    # kg CO2 offset
    }
}

@membership_bp.route('/tiers', methods=['GET'])
def get_membership_tiers():
    """Get all available membership tiers"""
    try:
        return jsonify({
            'success': True,
            'tiers': MEMBERSHIP_TIERS
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@membership_bp.route('/user/<int:user_id>', methods=['GET'])
def get_user_membership(user_id):
    """Get user's current membership details"""
    try:
        membership = USER_MEMBERSHIPS.get(user_id)
        
        if not membership:
            # Return basic membership for users without premium
            return jsonify({
                'success': True,
                'membership': {
                    'tier': 'basic',
                    'status': 'active',
                    'tier_details': MEMBERSHIP_TIERS['basic']
                }
            })
        
        # Add tier details
        tier_details = MEMBERSHIP_TIERS.get(membership['tier'], MEMBERSHIP_TIERS['basic'])
        membership_with_details = {
            **membership,
            'tier_details': tier_details
        }
        
        return jsonify({
            'success': True,
            'membership': membership_with_details
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@membership_bp.route('/upgrade', methods=['POST'])
def upgrade_membership():
    """Upgrade user membership to premium tier"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        target_tier = data.get('tier', 'premium')
        payment_method = data.get('payment_method', 'credit_card')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'User ID is required'
            }), 400
        
        if target_tier not in MEMBERSHIP_TIERS:
            return jsonify({
                'success': False,
                'error': 'Invalid membership tier'
            }), 400
        
        # Create or update membership
        start_date = datetime.now()
        expire_date = start_date + timedelta(days=365)  # 1 year membership
        
        new_membership = {
            'tier': target_tier,
            'status': 'active',
            'started_at': start_date.strftime('%Y-%m-%d'),
            'expires_at': expire_date.strftime('%Y-%m-%d'),
            'auto_renew': True,
            'payment_method': payment_method,
            'total_savings': 0.0,
            'carbon_offset': 0.0
        }
        
        USER_MEMBERSHIPS[user_id] = new_membership
        
        # Add tier details for response
        tier_details = MEMBERSHIP_TIERS[target_tier]
        
        return jsonify({
            'success': True,
            'message': f'Successfully upgraded to {tier_details["name"]}!',
            'membership': {
                **new_membership,
                'tier_details': tier_details
            },
            'welcome_bonus': {
                'tickets': tier_details['monthly_tickets'],
                'points': 1000  # Welcome bonus points
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@membership_bp.route('/benefits/<int:user_id>', methods=['GET'])
def get_membership_benefits(user_id):
    """Get detailed membership benefits and usage"""
    try:
        membership = USER_MEMBERSHIPS.get(user_id)
        
        if not membership:
            tier = 'basic'
        else:
            tier = membership['tier']
        
        tier_details = MEMBERSHIP_TIERS[tier]
        
        # Calculate monthly usage and benefits
        benefits_usage = {
            'tickets_used_this_month': random.randint(5, tier_details['monthly_tickets']),
            'tickets_remaining': max(0, tier_details['monthly_tickets'] - random.randint(5, tier_details['monthly_tickets'])),
            'points_earned_this_month': random.randint(500, 2000),
            'rewards_redeemed_this_month': random.randint(1, 5),
            'carbon_offset_this_month': round(random.uniform(5.0, 25.0), 1)
        }
        
        return jsonify({
            'success': True,
            'tier': tier,
            'tier_details': tier_details,
            'benefits_usage': benefits_usage,
            'membership': membership
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@membership_bp.route('/savings/<int:user_id>', methods=['GET'])
def get_membership_savings(user_id):
    """Get user's savings and environmental impact from membership"""
    try:
        membership = USER_MEMBERSHIPS.get(user_id)
        
        if not membership:
            return jsonify({
                'success': True,
                'savings': {
                    'total_savings_aed': 0.0,
                    'carbon_offset_kg': 0.0,
                    'plastic_bottles_prevented': 0,
                    'membership_value': 0.0
                }
            })
        
        # Calculate savings and impact
        savings_data = {
            'total_savings_aed': membership.get('total_savings', 450.75),
            'carbon_offset_kg': membership.get('carbon_offset', 125.5),
            'plastic_bottles_prevented': random.randint(50, 200),
            'membership_value': MEMBERSHIP_TIERS[membership['tier']]['price'],
            'roi_percentage': round((membership.get('total_savings', 450.75) / MEMBERSHIP_TIERS[membership['tier']]['price']) * 100, 1) if MEMBERSHIP_TIERS[membership['tier']]['price'] > 0 else 0
        }
        
        return jsonify({
            'success': True,
            'savings': savings_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@membership_bp.route('/cancel', methods=['POST'])
def cancel_membership():
    """Cancel user's premium membership"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        reason = data.get('reason', 'User request')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'User ID is required'
            }), 400
        
        membership = USER_MEMBERSHIPS.get(user_id)
        
        if not membership:
            return jsonify({
                'success': False,
                'error': 'No active membership found'
            }), 404
        
        # Update membership status
        membership['status'] = 'cancelled'
        membership['cancelled_at'] = datetime.now().strftime('%Y-%m-%d')
        membership['cancellation_reason'] = reason
        membership['auto_renew'] = False
        
        return jsonify({
            'success': True,
            'message': 'Membership cancelled successfully',
            'membership': membership,
            'downgrade_date': membership['expires_at']  # When they'll be downgraded to basic
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

