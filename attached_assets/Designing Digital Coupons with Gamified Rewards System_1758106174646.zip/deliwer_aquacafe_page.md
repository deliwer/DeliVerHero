# DeliWer - Dubai's iPhone to Water Trade Platform | Earn Rewards, Save Planet

Welcome Bonus: Get Bakers Kitchen AED100 Kangen Water voucher when a friend signs up!SHARE

# 💧 "Pure Water. Real Rewards."

Upgrade your lifestyle with AquaCafe Water Purification solutions and earn Planet Points every step of the way — from Starter Kits to Packages and Referrals.

[Get My Starter Kit (AED 99)]()See How Planet Points Work

Water Filtration

×

Healthy Dining

## Why AquaCafe + Baker's Kitchen?

The perfect synergy of pure water and wholesome nutrition for your health and our planet

Go to Checkout

### AquaCafe by DeliWer

Eco-Friendly Water Filtration

Plastic-free solutions

Kangen technology

Family hydration

7-stage filtration

### Baker's Kitchen UAE

Healthy Restaurant Experience

Fresh meals

Kangen Water served

Mazaya Center

Gourmet experience

Visit Baker's Kitchen Mazaya Center

Mazaya Center, Business Bay

Open Daily 9AM-11PM

## 🎁 Refer Friends, Earn Rewards! 🎁

Share the wellness journey with your friends and family. Every successful referral earns you exclusive vouchers at Baker's Kitchen and extra Planet Points!

🤝

### Invite Friends

Share your unique referral code with friends and family

🛒

### They Join & Order

Friends sign up and purchase any AquaCafe starter kit

🎁

### You Get Rewards

Receive AED 100 Baker's Kitchen vouchers + bonus Planet Points

🚀 AQUACAFE LOYALTY GATEWAY - YOUR CIRCULAR EXCHANGE HUB 🚀

# AED 99  
Starter Kit

Your gateway to AquaCafe's comprehensive loyalty ecosystem - where sustainability meets rewards, trade-ins become Planet Points, and every action contributes to Dubai's circular economy.

## 🔄 THE CIRCULAR EXCHANGE CONCEPT 🔄

This starter kit isn't just a product - it's your lifetime membership to Dubai's most innovative sustainability platform. Every feature works together to create continuous value and environmental impact.

### Trade-In Hub

iPhone valuations, tech exchanges, and instant Planet Points earning through your membership portal.

### Rewards Engine

Planet Points redemption, Baker's Kitchen vouchers, and exclusive member discounts on all AquaCafe products.

### Community Impact

Awareness campaigns, environmental initiatives, and social engagement activities exclusive to members.

### 💎 LIFETIME MEMBERSHIP BENEFITS (AED 1000+ VALUE)

FREE Ionic Shower Filter(AED 399 value)

Premium beauty & skincare filtration system

FREE Membership Card & Setup(AED 299 value)

Professional installation & lifetime support

Baker's Kitchen Partnership(AED 100+ per referral)

Free vouchers + Kangen Water demos

Planet Hero Level 2 Status(Exclusive Access)

Priority support, special events, premium features

### 🔄 CONTINUING MEMBER BENEFITS

Lifetime discounts on all products

Priority trade-in valuations

Exclusive Planet Points bonuses

Community event invitations

AED 99

One-time investment

Lifetime Value: AED 1000+ in benefits

[START YOUR CIRCULAR JOURNEY]()

Join thousands of Dubai residents building a sustainable future through the circular economy.

### 🤝 BAKER'S KITCHEN PARTNERSHIP EXPERIENCE

Your membership includes exclusive access to Kangen Water demonstrations and healthy dining experiences at Baker's Kitchen Mazaya Center. Every friend you refer earns you both AED 100 vouchers - it's sustainability that pays forward.

Mazaya Center, Business Bay

Open Daily 9AM-11PM

PARTNERSHIP REFERRAL REWARDS

## Refer Friends & Get AED 100 FREE VOUCHER at Baker's Kitchen!

1

### Share Code

Get unique referral code

2

### Friend Joins

They purchase using code

3

### Both Win!

AED 100 voucher each

🍰 Exclusive Partnership with Baker's Kitchen Dubai 🍰

Use your AED 100 voucher at Baker's Kitchen Mazaya Center for Kangen Water experience!

Mazaya Center, Business Bay

Visit bakerskitchenuae.com

## 🏆 PARTNERSHIP PACKAGES

Choose the perfect AquaCafe package with Baker's Kitchen perks

🚀 PLANET HERO GATEWAY

### AquaCafe Hero Minimal - PLANET HERO ENTRY

AED 1,599

AED 1,299

SAVE AED 300 + BAKER'S REFERRAL PERKS!

💧 Premium 3-stage filtration system

📦 12-month filter supply included

⭐ Instant Planet Hero Level 2 status

🎯 1000 starter points + 2X Hero multiplier

📞 24/7 Planet Hero priority support

📱 Smart monitoring app with Hero dashboard

🏆 Exclusive Hero member badge

💰 20% discount on ALL future plans

🍰 AED 100 Baker's Kitchen voucher when friend signs up via referral

AR PreviewSTART JOURNEY

⚡ MOST POPULAR

### AquaCafe Hero Premium

AED 1,999

AED 1,499

Save AED 500

Advanced 5-stage filtration

18-month filter supply

Planet Hero Level 3 status

2500 starter points + 2X multiplier

24/7 priority phone support

Smart water quality monitoring

Exclusive Hero premium badge

Free home installation

AR PreviewUPGRADE NOW

🏆 ULTIMATE HERO

### AquaCafe Hero Elite

AED 2,999

AED 2,299

Save AED 700

Ultimate 7-stage whole-home system

36-month filter supply

Planet Hero Level 4 Elite status

5000 starter points + 3X multiplier

24/7 VIP concierge support

AI-powered smart home integration

Elite Hero platinum badges

Free annual maintenance & upgrades

Carbon footprint certificate

AR PreviewORDER NOW

### Context Tips

Choose which tips to display

#### Hero Water Systems

tip

Use your iPhone trade credit towards premium AquaCafe water ...

Show

Reset All

CancelDismiss All

